exports.cassandra = {
    hosts: ['10.16.76.249:9160'],
    keyspace: 'servermonitor',
    columnFamily: 'Servers'
};

exports.expressloglevel = 'dev';

exports.authorization = 'newegg.server.monitor.center';

exports.timeOut = 20000;
exports.cacheTTL = 15;
exports.managementPort = 8701;
exports.monitorServerPort = 3000;
exports.domaindatalastupdate = undefined;
exports.sqliteUpdateOption = { syncsqliteinternal: 86400000, checksqliteinternal: 14400000, processmintime: 0, processmaxtime: 4 };
exports.doaminAPI = 'http://apis.newegg.org/common/v1/domain/';