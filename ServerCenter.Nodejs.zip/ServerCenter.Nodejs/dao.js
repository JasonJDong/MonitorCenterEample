var helenus = require('helenus');
var async = require('async');
var config = require('./config');
var util = require('./util');
var http = require('http');
var agent = require('agentkeepalive');
var pool = null;

var sqlite = util.sqliteutil;

var keepAgent = new agent({
    maxSockets: 50,
    maxKeepAliveTime: 0
});

function getCassandraClient() {
    return new helenus.ConnectionPool({
        hosts: config.cassandra.hosts,
        keyspace: config.cassandra.keyspace
    });
};

function buildCols(cols) {
    var result = [];
    if (cols.length > 0) {
        for (var i = 0; i < cols.length; i++) {
            result.push({
                'name': cols[i].name,
                "value": cols[i].value
            });
        }
    }

    return result;
}

function buildServerInfo(group, serverName, serverCols) {

    var server = {
        Name: serverName
    };

    for (var i = 0; i < serverCols.length; i++) {

        var serverCol = serverCols[i];

        if ('cache' == serverCol.name && serverCol.value) {
            server.Cache = JSON.parse(serverCol.value);
        } else if ('managementPort' == serverCol.name) {
            server.ManagementPort = serverCol.value;
        } else if (group == serverCol.name) {
            server.GroupName = group;
            var obj = JSON.parse(serverCol.value);

            server.Listen = obj.ListenServer;
            server.Interval = obj.Interval;
            server.Memo = obj.Memo;
            server.IP = obj.IP;
            server.Cpu = {
                Listen: obj.ListenCpu,
                Juevalue: obj.CpuJuevalue
            };
            server.Memory = {
                Listen: obj.ListenMemory,
                Juevalue: obj.MemoryJuevalue
            };
            server.Disk = obj.Disk;
            buildServerModuleInfo(obj, server);
        }
    }

    return server;
}

function buildServerModuleInfo(groupModule, server) {
    server.Modules = [];
    if (groupModule) {
        if (groupModule.Jobs) {
            for (var j = 0; j < groupModule.Jobs.length; j++) {
                groupModule.Jobs[j].ModuleType = 'Job';
                server.Modules.push(groupModule.Jobs[j]);
            }
        }
        if (groupModule.Webs) {
            for (var k = 0; k < groupModule.Webs.length; k++) {
                groupModule.Webs[k].ModuleType = 'Web';
                server.Modules.push(groupModule.Webs[k]);
            }
        }
    }
}

function getDataByRowKey(key, cb) {

    pool.cql("SELECT * FROM " + config.cassandra.columnFamily + " WHERE key = ?", [key], function (err, row) {
        if (err) {
            cb([])
        }
        else if (row.length >= 1) {
            cb(row[0]);
        }
    });
}

function fillServerInfo(server, serverInfo, groupname) {

    //scale server status
    var status = 0;
    var exists = false;
    try {
        if (serverInfo.Memory) {
            server.Memory.Process = serverInfo.Memory.Process;
            server.Memory.Description = serverInfo.Memory.Description;
            server.Platform = serverInfo.Platform;
            if (serverInfo.Memory.Regions !== undefined) {
                server.Memory.Regions = serverInfo.Memory.Regions;
            }

            server.Cpu.Process = serverInfo.Cpu.Process;
            server.Cpu.Speed = serverInfo.Cpu.Speed;
            server.Cpu.Description = serverInfo.Cpu.Description;
            server.Cpu.Cpus = serverInfo.Cpu.Cpus;
            //server.Tasks = serverInfo.Tasks;

            if (serverInfo.Disk) {
                if (server.Disk == null) server.Disk = [];
                for (var i = 0; i < serverInfo.Disk.length; i++) {
                    var disk = serverInfo.Disk[i];
                    exists = false;
                    for (var j = 0 ; j < server.Disk.length; j++) {

                        if (server.Disk[j].Name == disk.Name.trim()) {
                            server.Disk[j].Description = disk.Description;
                            server.Disk[j].Process = disk.Process;
                            exists = true;
                            break;
                        }
                    }

                    if (exists == false) {
                        server.Disk.push({
                            Name: disk.Name.trim(),
                            Process: disk.Process,
                            Description: disk.Description,
                            Listen: true,
                            Juevalue: 0
                        })
                    } else
                        exists = false
                }
            }

            if (server.Modules == null) server.Modules = [];
            var modules = server.Modules;
            var totalMoudules = 0;
            //fill jobs
            var jobs = serverInfo.Jobs;
            if (jobs) {
                for (var i = 0, l = jobs.length; i < l; i++) {
                    var job = jobs[i];
                    for (var j = 0, len = modules.length; j < len; j++) {
                        var module = modules[j];
                        if (module.ModuleType === 'Job' && module.Name == job.Name) {
                            module.Normal = job.Normal;
                            totalMoudules++;
                        }
                    }
                }
            }

            //fill webs
            var webs = serverInfo.Webs;
            if (webs) {
                for (var i = 0, l = webs.length; i < l; i++) {
                    var web = webs[i];
                    for (var j = 0, len = modules.length; j < len; j++) {
                        var module = modules[j];
                        if (module.ModuleType === 'Web' && module.URI == web.URI && module.ValidType == web.ValidType && module.ValidValue == web.ValidValue) {
                            module.Normal = web.Normal;
                            totalMoudules++;
                        }
                    }
                }
            }

            if (totalMoudules != server.Modules.length) {
                util.postServerConfig(server.IP || server.Name, server.ManagementPort, { Action: 'Update', Interval: server.Interval, Modules: server.Modules }, null);
            }


            // scale server cpu status
            server.Cpu.ServerItemState = 0;
            if (server.Cpu.Juevalue !== 0) {
                server.Cpu.ServerItemState = server.Cpu.Process >= server.Cpu.Juevalue ? 1 : 0;
                if (server.Cpu.ServerItemState === 1) {
                    status = 1;
                }
            }

            // scale server Memory status
            server.Memory.ServerItemState = 0;
            if (server.Memory.Juevalue !== 0) {
                server.Memory.ServerItemState = server.Memory.Process >= server.Memory.Juevalue ? 1 : 0;
                if (server.Memory.ServerItemState === 1) {
                    status = 1;
                }
            }

            // scale server Disk status
            var disks = server.Disk;
            for (var i = 0, l = disks.length; i < l; i++) {
                var disk = disks[i];
                disk.ServerItemState = 0;
                if (disk.Juevalue) {
                    disk.ServerItemState = disk.Process >= disk.Juevalue ? 1 : 0;
                    if (disk.ServerItemState == 1) {
                        status = 1;
                    }
                }
            }

            // scale server Module status
            for (var i = 0, l = modules.length; i < l ; i++) {
                var module = modules[i];
                module.ServerItemState = module.Normal ? 0 : 2;
                if (module.ServerItemState === 2) {
                    status = 1;
                }
                delete module.Normal;
            }

            server.ServerItemState = status;
        } else {
            server.ServerItemState = 2;
            if (server.Modules) {
                for (var i = 0; i < server.Modules.length; i++) {
                    server.Modules[i].ServerItemState = 2;
                }
            }
        }
    } catch (e) {
        util.error('fill server info', groupname, server.Name, serverInfo, e);
        server.ServerItemState = 2;
        if (server.Modules) {
            for (var i = 0; i < server.Modules.length; i++) {
                server.Modules[i].ServerItemState = 2;
            }
        }
    }
}
function pushServers(servers, server) {
    if (servers) {
        var exists = false;
        for (var i = 0; i < servers.length; i++) {
            if (servers[i].Name == server.Name) {
                exists = true;
                break;
            }
        }

        if (exists == false) {
            servers.push(server);
        }
    }
}

function pushGroups(groupKey, groups, servers) {
    if (groupKey && servers) {
        var exists = false;
        for (var i = 0; i < groups.length; i++) {
            if (groups[i].Name == groupKey.name) {
                exists = true;
                break;
            }
        }

        if (exists == false) {
            groups.push({
                'Name': groupKey.name,
                'Servers': servers,
                'ReadOnly': groupKey.value
            });
        }
    }
}

function deleteServerData(server) {
    if (server && server.Name) {
        getDataByRowKey(server.Name, function (cols) {

            var count = 0;
            for (var i = 0; i < cols.length; i++) {
                if (cols[i].name == 'cache' || cols[i].name == 'managementPort') {
                    count++;
                }
            }
            pool.cql("SELECT ? FROM " + config.cassandra.columnFamily + " USING CONSISTENCY QUORUM WHERE KEY = servers", [server.Name], function (err, row) {
                if (row[0].length == 1) {
                    var obj = JSON.parse(row[0][0].value);
                    if (server.Modules) {
                        util.postServerConfig(obj.IP || server.Name,
                            obj.Port,
                            { Action: 'Delete', Interval: 0, Modules: server.Modules }, null);
                    }
                }
                if (cols.length - count == 0) {
                    pool.cql("DELETE ? FROM " + config.cassandra.columnFamily + " USING CONSISTENCY QUORUM WHERE KEY = servers", [server.Name]);
                }
            })

        });
    }
}

exports.getServers = function (userID, cb) {
    if (userID) {
        var key = 'user:' + userID;

        getDataByRowKey(key, function (groupCols) {
            async.reduce(buildCols(groupCols), [], function (groups, groupKey, callBack) {
                getDataByRowKey("group:" + groupKey.name, function (serverCols) {
                    if (serverCols.length > 0) {
                        async.reduce(buildCols(serverCols), [], function (servers, serverKey, serverCallback) {
                            pool.cql("SELECT managementPort,?,cache FROM " + config.cassandra.columnFamily + " WHERE key = ?", [groupKey.name, serverKey.name], function (err, serverRow) {
                                if (err) {
                                    serverCallback(err, servers);
                                }
                                else if (serverRow.length >= 1) {
                                    var serverCols = serverRow[0];
                                    var server = buildServerInfo(groupKey.name, serverKey.name, serverCols);
                                    if (server.Cache) {
                                        fillServerInfo(server, server.Cache, groupKey.name);
                                        server.Cache = null;
                                        pushServers(servers, server);
                                        serverCallback(null, servers);

                                    } else {
                                        server.ServerItemState = 2;
                                        pushServers(servers, server);
                                        serverCallback(null, servers);
                                    }
                                }
                            })
                        }, function (err, servers) {
                            pushGroups(groupKey, groups, servers);
                            callBack(err, groups);
                        });
                    } else callBack(null, groups);
                })
            }, function (err, allgroups) {
                cb(allgroups);
            })
        })

    } else cb();
}

exports.addServer = function (server, cb) {
    if (server && server.Name && server.GroupName) {
        getDataByRowKey(server.Name, function (groupRow) {
            pool.cql("BEGIN BATCH USING CONSISTENCY QUORUM  INSERT INTO " + config.cassandra.columnFamily + " (KEY, ?) VALUES (?, ?) INSERT INTO " + config.cassandra.columnFamily + " (KEY, ?, managementPort) VALUES (?, ?, ?) INSERT INTO " + config.cassandra.columnFamily + " (KEY, ?) VALUES (servers, ?) APPLY BATCH;", [server.Name, "group:" + server.GroupName, '', server.GroupName, server.Name, JSON.stringify({
                ListenServer: true,
                Interval: 5,
                ListenCpu: true,
                ListenMemory: true,
                IP: server.IP,
                Memo: server.Memo
            }), config.managementPort, server.Name, JSON.stringify({ IP: server.IP, Port: config.managementPort })], function (err, result) {
                if (err) cb({
                    StatusCode: 500
                });
                else {
                    server.StatusCode = 200;
                    cb(server);
                }
            });

        });
    } else cb({
        StatusCode: 500
    });
}

exports.deleteServer = function (server, cb) {

    if (server && server.Name && server.GroupName) {
        pool.cql("BEGIN BATCH USING CONSISTENCY QUORUM  DELETE ? FROM " + config.cassandra.columnFamily + " WHERE KEY = ? DELETE ? FROM " + config.cassandra.columnFamily + " WHERE KEY = ? APPLY BATCH;", [server.GroupName, server.Name, server.Name, "group:" + server.GroupName], function (err, result) {
            if (err) cb({
                StatusCode: 500
            });
            else {
                cb({
                    StatusCode: 200
                });
                deleteServerData(server);
            }
        });
    } else cb({
        StatusCode: 500
    });
}

exports.updateServer = function (server, cb) {
    if (server && server.GroupName) {
        var commandline = "BEGIN BATCH USING CONSISTENCY QUORUM ";
        var commandParams = [];
        commandline += " INSERT INTO " + config.cassandra.columnFamily + " (KEY, ?) VALUES (?,?) ";
        commandParams.push(server.GroupName);
        commandParams.push(server.Name);

        var groupConfig = {
            ListenServer: server.Listen,
            Interval: server.Interval,
            Memo: server.Memo,
            ListenCpu: server.Cpu.Listen,
            CpuJuevalue: server.Cpu.Juevalue,
            ListenMemory: server.Memory.Listen,
            MemoryJuevalue: server.Memory.Juevalue,
            IP: server.IP
        };

        if (server.Disk) {
            var diskConfig = [];

            for (var i = 0 ; i < server.Disk.length; i++) {
                var disk = server.Disk[i];
                diskConfig.push({ Name: disk.Name, Listen: disk.Listen, Juevalue: disk.Juevalue });
            }
            groupConfig.Disk = diskConfig;
        }
        if (server.Modules) {
            groupConfig.Webs = [];
            groupConfig.Jobs = [];
            for (var i = 0; i < server.Modules.length; i++) {
                var module = server.Modules[i];
                if (module.ModuleType == 'Job') {
                    groupConfig.Jobs.push({ Interval: module.Interval, Listen: module.Listen, Name: module.Name });
                } else if (module.ModuleType == 'Web') {
                    groupConfig.Webs.push({ Interval: module.Interval, Listen: module.Listen, Name: module.Name, URI: module.URI, ValidType: module.ValidType, ValidValue: module.ValidValue });
                }
            }
        }

        commandParams.push(JSON.stringify(groupConfig));


        commandline += " INSERT INTO " + config.cassandra.columnFamily + " (KEY, ?) VALUES (servers, ?) ";
        commandParams.push(server.Name);
        commandParams.push(JSON.stringify({ IP: server.IP, Port: config.managementPort }));


        commandline += " APPLY BATCH;";

        pool.cql(commandline, commandParams, function (err, result) {
            if (err) {
                util.error('updateServer', err);
                cb({
                    StatusCode: 500
                });
            }
            else {
                cb({
                    StatusCode: 200
                });
                util.postServerConfig(server.IP || server.Name, server.ManagementPort, { Action: 'Update', Interval: server.Interval, Modules: server.Modules }, null);
            }
        });

    } else cb({
        StatusCode: 500
    });
}

exports.addGroup = function (group, cb) {

    var hasError = true;

    if (group && group.Name && group.UserID && group.Servers && group.Servers.length > 0) {
        hasError = false;
        for (var i = 0; i < group.Servers.length; i++) {
            if (group.Servers[i].Name == undefined || group.Servers[i].Name == '') {
                hasError = true;
                break;
            }
        }
    }

    if (hasError == false) {
        var key = "group:" + group.Name;
        getDataByRowKey(key, function (groupRow) {
            if (groupRow.length >= 1) {
                cb({
                    StatusCode: 403,
                    Name: group.Name
                });
            } else {

                var commandline = "BEGIN BATCH USING CONSISTENCY QUORUM ";
                var commandParams = [];
                var userKey = "user:" + group.UserID;

                for (var i = 0; i < group.Servers.length; i++) {
                    var server = group.Servers[i];
                    commandline += " INSERT INTO " + config.cassandra.columnFamily + " (KEY, ?) VALUES (?, ?) INSERT INTO " + config.cassandra.columnFamily + " (KEY, ?) VALUES (?, ?) INSERT INTO " + config.cassandra.columnFamily + " (KEY,?,managementPort) VALUES (?,?,?) INSERT INTO " + config.cassandra.columnFamily + " (KEY,?) VALUES (?,?) INSERT INTO " + config.cassandra.columnFamily + " (KEY,?) VALUES (servers,?) ";
                    commandParams.push(server.Name);
                    commandParams.push(key);
                    commandParams.push('');
                    commandParams.push(group.Name);
                    commandParams.push(userKey);
                    commandParams.push('false');
                    commandParams.push(group.Name);
                    commandParams.push(server.Name);
                    commandParams.push(JSON.stringify({
                        ListenServer: true,
                        Interval: 5,
                        ListenCpu: true,
                        ListenMemory: true,
                        Memo: server.Memo
                    }));
                    commandParams.push(config.managementPort);
                    commandParams.push(group.UserID);
                    commandParams.push("group:" + group.Name + ":users");
                    commandParams.push('false');
                    commandParams.push(server.Name);
                    commandParams.push(JSON.stringify({ IP: server.IP, Port: config.managementPort }));
                }

                commandline += " APPLY BATCH;";

                pool.cql(commandline, commandParams, function (err, result) {
                    if (err) cb({
                        StatusCode: 500
                    });
                    else {
                        group.StatusCode = 200;
                        cb(group);
                    }
                });
            }
        });
    } else cb({
        StatusCode: 500
    });
}

exports.deleteGroup = function (group, cb) {

    if (group && group.Name) {
        getDataByRowKey("group:" + group.Name + ":users", function (cols) {
            getDataByRowKey("group:" + group.Name + ":groups", function (groupcols) {
                var commandline = "BEGIN BATCH USING CONSISTENCY QUORUM ";
                var commandParams = [];
                cols = cols || [];
                for (var i = 0; i < cols.length; i++) {
                    commandline += " DELETE ? FROM " + config.cassandra.columnFamily + " WHERE KEY = ?";
                    commandParams.push(group.Name);
                    commandParams.push('user:' + cols[i].name);
                }

                if (group.Servers) {
                    for (var j = 0; j < group.Servers.length; j++) {
                        commandline += " DELETE ? FROM " + config.cassandra.columnFamily + " WHERE KEY = ? ";
                        commandParams.push(group.Name);
                        commandParams.push(group.Servers[j].Name);
                    }
                }

                commandline += " DELETE FROM " + config.cassandra.columnFamily + " WHERE KEY = ? DELETE FROM " + config.cassandra.columnFamily + " WHERE KEY = ? ";
                commandParams.push("group:" + group.Name);
                commandParams.push("group:" + group.Name + ":users");


                groupcols = groupcols || [];
                commandline += " DELETE FROM " + config.cassandra.columnFamily + " WHERE KEY = ? ";
                commandParams.push("group:" + group.Name + ":groups");

                async.reduce(buildCols(groupcols), { line: commandline, params: commandParams }, function (cmd, emailgroup, callback) {
                    sqlite.getGroupUsers(emailgroup.name, function (err, result) {
                        if (!err && result && result.users) {
                            var users = result.users.split(',');
                            for (var i = 0; i < users.length; i++) {
                                var userId = users[i].trim();
                                cmd.line += " DELETE ? FROM " + config.cassandra.columnFamily + " WHERE KEY = ? ";
                                cmd.params.push(group.Name);
                                cmd.params.push('user:' + userId);
                            }
                        }
                        callback(null, cmd);
                    });
                }, function (err, cmd) {
                    cmd.line += " APPLY BATCH;";
                    pool.cql(cmd.line, cmd.params, function (err, result) {
                        if (err) {
                            console.log(err);
                            cb({ StatusCode: 500 });
                        }
                        else {
                            cb({ StatusCode: 200 });
                            if (group.Servers) {
                                for (var k = 0; k < group.Servers.length; k++) {
                                    deleteServerData(group.Servers[k]);
                                }
                            }
                        }
                    });
                });
            });
        });
    } else cb({
        StatusCode: 500
    });
}

exports.getGroupAuthorization = function (userID, cb) {
    if (userID) {
        var key = "user:" + userID;
        getDataByRowKey(key, function (groupRow) {
            async.reduce(buildCols(groupRow), [], function (groupUsers, groupUserKey, callBack) {
                if (groupUserKey.value == 'false') {
                    getDataByRowKey("group:" + groupUserKey.name + ":users", function (cols) {

                        cols = cols || [];

                        var users = [];

                        for (var i = 0; i < cols.length; i++) {
                            users.push({
                                UserID: cols[i].name,
                                ReadOnly: cols[i].value
                            });
                        }

                        groupUsers.push({
                            Name: groupUserKey.name,
                            Users: users
                        });
                        callBack(null, groupUsers);
                    });
                } else callBack(null, groupUsers);
            }, function (err, allGroupUsers) {
                cb(allGroupUsers)
            });
        });
    } else cb({ StatusCode: 500 });
}

exports.updateGroupAuthorization = function (groupAuthorization, cb) {
    if (groupAuthorization && groupAuthorization.Name && groupAuthorization.Users && groupAuthorization.Users.length > 0) {
        var commandline = "BEGIN BATCH USING CONSISTENCY QUORUM ";
        var commandParams = [];


        for (var i = 0; i < groupAuthorization.Users.length; i++) {
            commandline += " INSERT INTO " + config.cassandra.columnFamily + " (KEY, ?) VALUES (?, ?) INSERT INTO " + config.cassandra.columnFamily + " (KEY, ?) VALUES (?, ?) ";
            commandParams.push(groupAuthorization.Name);
            commandParams.push("user:" + groupAuthorization.Users[i].UserID);
            commandParams.push(groupAuthorization.Users[i].ReadOnly);
            commandParams.push(groupAuthorization.Users[i].UserID);
            commandParams.push("group:" + groupAuthorization.Name + ":users");
            commandParams.push(groupAuthorization.Users[i].ReadOnly);
        }

        commandline += " APPLY BATCH;";

        pool.cql(commandline, commandParams, function (err, result) {
            if (err) {
                util.error('updateGroupAuthorization', err);
                cb({
                    StatusCode: 500
                });
            }
            else {
                cb({
                    StatusCode: 200
                });
            }
        });

    } else cb({
        StatusCode: 500
    });
}


// modifed by benjamin.c.cyan
// 2013-08-16 17:00:00
// description: delete changed by groups
exports.deleteGroupAuthorization = function (groupAuthorization, cb) {

    if (groupAuthorization && groupAuthorization.Name && groupAuthorization.Users && groupAuthorization.Users.length > 0) {

        var grouprowkey = 'group:' + groupAuthorization.Name + ':groups';

        getDataByRowKey(grouprowkey, function (groupcols) {

            var originalGroupUserAuthority = {};
            async.each(buildCols(groupcols), function (groupcol, callback) {

                var groupname = groupcol.name;

                sqlite.getGroupUsers(groupname, function (err, result) {
                    if (!err && result && result.users) {

                        var users = result.users.split(',');

                        for (var j = 0; j < users.length; j++) {
                            var userId = users[j].trim();

                            originalGroupUserAuthority[userId] = originalGroupUserAuthority[userId] || [];
                            originalGroupUserAuthority[userId].push(groupcol.value === 'false');
                        }
                    }
                    callback(null);
                });

            }, function (err) {
                var commandline = "BEGIN BATCH USING CONSISTENCY QUORUM ";
                var commandParams = [];

                for (var i = 0; i < groupAuthorization.Users.length; i++) {

                    var usermodel = groupAuthorization.Users[i];

                    commandline += " DELETE ? FROM " + config.cassandra.columnFamily + " WHERE KEY = ?";
                    commandParams.push(usermodel.UserID);
                    commandParams.push("group:" + groupAuthorization.Name + ":users");

                    var auths = originalGroupUserAuthority[usermodel.UserID];

                    // if other share group contains the user, need to fix the user's authority.
                    // otherwise, delete the user directly
                    if (auths !== undefined && auths.length > 0) {

                        commandline += " INSERT INTO " + config.cassandra.columnFamily + " (KEY, ?) VALUES (?, ?) ";
                        commandParams.push(groupAuthorization.Name);
                        commandParams.push("user:" + usermodel.UserID);

                        if (auths.indexOf(true) >= 0) {
                            commandParams.push(false);
                        } else {
                            commandParams.push(true);
                        }

                    } else {

                        commandline += " DELETE ? FROM " + config.cassandra.columnFamily + " WHERE KEY = ?";
                        commandParams.push(groupAuthorization.Name);
                        commandParams.push("user:" + usermodel.UserID);
                    }
                }

                commandline += " APPLY BATCH;";

                pool.cql(commandline, commandParams, function (err, result) {
                    if (err) {
                        util.error(err);
                        cb({ StatusCode: 500 });
                    }
                    else cb({ StatusCode: 200 });
                });
            });


        });

    } else {
        cb({ StatusCode: 500 });
    }
}

//added by benjamin.c.yan
//2013-08-16 15:00:00
//description: share group by usergroup

exports.getGroupAuthorizationByUserGroup = function (userID, cb) {
    if (userID) {
        userID = userID.toLowerCase();
        var key = "user:" + userID;
        getDataByRowKey(key, function (groupRow) {
            async.reduce(buildCols(groupRow), [], function (groupUserGroups, groupUserGroupsKey, callBack) {

                if (groupUserGroupsKey.value == 'false') {
                    getDataByRowKey("group:" + groupUserGroupsKey.name + ":groups", function (cols) {
                        if (cols && cols.length > 0) {

                            var groups = [];

                            for (var i = 0; i < cols.length; i++) {
                                groups.push({
                                    GroupName: cols[i].name,
                                    ReadOnly: cols[i].value !== 'false'
                                });
                            }

                            groupUserGroups.push({
                                Name: groupUserGroupsKey.name,
                                Groups: [].concat(groups)
                            });
                        }

                        callBack(null, groupUserGroups);
                    });
                } else {
                    callBack(null, groupUserGroups);
                }
            }, function (err, allGroupUserGroups) {
                cb(allGroupUserGroups)
            });
        });
    } else cb({ StatusCode: 500 });
}

exports.updateGroupAuthorizationByUserGroup = function (groupAuthorization, cb) {

    if (groupAuthorization && groupAuthorization.Name && groupAuthorization.Groups && groupAuthorization.Groups.length > 0) {

        groupAuthorization.Name = groupAuthorization.Name.toLowerCase();
        // get all users under current group
        var rowkey = 'group:' + groupAuthorization.Name + ':users';
        getDataByRowKey(rowkey, function (cols) {

            // constructor group user's authority.
            // true if authority is administrator; otherwise, false
            var groupUserAuthority = {};

            // constructor share user's authority.
            // true if authority is administrator; otherwise, false

            var userAuthority = {};
            for (var i = 0; i < cols.length; i++) {
                userAuthority[cols[i].name] = cols[i].value === 'false';
            }

            async.reduce(groupAuthorization.Groups, { commandline: 'BEGIN BATCH USING CONSISTENCY QUORUM ', commandParams: [] }, function (command, group, callback) {

                group.GroupName = group.GroupName.toLowerCase();

                command.commandline += " INSERT INTO " + config.cassandra.columnFamily + " (KEY, ?) VALUES (?, ?) ";
                command.commandParams.push(group.GroupName);
                command.commandParams.push("group:" + groupAuthorization.Name + ":groups");
                command.commandParams.push(group.ReadOnly);

                sqlite.getGroupUsers(group.GroupName, function (err, result) {
                    if (!err && result && result.users) {
                        var users = result.users.split(',');

                        for (var i = 0; i < users.length; i++) {
                            var userId = users[i];
                            // administrator authority priority
                            if (!groupUserAuthority[userId]) {
                                groupUserAuthority[userId] = !group.ReadOnly;
                            }
                        }
                    }
                    callback(null, command);
                });
            }, function (err, command) {
                if (!err) {
                    for (var username in groupUserAuthority) {

                        // if the group already share to the user, don't do anything;
                        // otherwise; set the authority by usershare's authority
                        if (userAuthority[username] === undefined) {
                            command.commandline += " INSERT INTO " + config.cassandra.columnFamily + " (KEY, ?) VALUES (?, ?) ";
                            command.commandParams.push(groupAuthorization.Name);
                            command.commandParams.push("user:" + username);
                            command.commandParams.push(!groupUserAuthority[username]);
                        }
                    }

                    command.commandline += " APPLY BATCH;";
                    pool.cql(command.commandline, command.commandParams, function (err, result) {
                        if (err) {
                            util.error('updateGroupAuthorization', err);
                            cb({ StatusCode: 500 });
                        }
                        else {
                            cb({ StatusCode: 200 });
                        }
                    });
                } else {
                    cb({ StatusCode: 500 });
                }
            });
        });
    } else {
        cb({ StatusCode: 500 });
    }
}

exports.deleteGroupAuthorizationByUserGroup = function (groupAuthorization, cb) {
    if (groupAuthorization && groupAuthorization.Name && groupAuthorization.Groups && groupAuthorization.Groups.length > 0) {
        // get all users under current group

        groupAuthorization.Name = groupAuthorization.Name.toLowerCase();

        var userrowkey = 'group:' + groupAuthorization.Name + ':users';

        getDataByRowKey(userrowkey, function (usercols) {

            var grouprowkey = 'group:' + groupAuthorization.Name + ':groups';
            getDataByRowKey(grouprowkey, function (groupcols) {

                var groupUserAuthority = {};
                var originalGroupUserAuthority = {};
                var userAuthority = {};
                var groupAuthority = {};


                // constructor share user's authority.
                // true if authority is administrator; otherwise, false
                for (var i = 0; i < usercols.length; i++) {
                    userAuthority[usercols[i].name] = usercols[i].value === 'false';
                }
                async.each(buildCols(groupcols), function (groupcol, callback) {

                    var groupname = groupcol.name;
                    groupAuthority[groupname] = groupcol.value === 'false';

                    sqlite.getGroupUsers(groupname, function (err, result) {
                        if (!err && result && result.users) {
                            var users = result.users.split(',');
                            for (var j = 0; j < users.length; j++) {

                                var userId = users[j].trim();

                                originalGroupUserAuthority[userId] = originalGroupUserAuthority[userId] || [];
                                originalGroupUserAuthority[userId].push(groupAuthority[groupname]);
                            }
                        }
                        callback(null);
                    });
                }, function (err) {

                    async.reduce(groupAuthorization.Groups, { commandline: 'BEGIN BATCH USING CONSISTENCY QUORUM ', commandParams: [] }, function (cmd, group, callback) {

                        group.GroupName = group.GroupName.toLowerCase();
                        var groupname = group.GroupName;

                        cmd.commandline += " DELETE ? FROM " + config.cassandra.columnFamily + " WHERE KEY = ? ";
                        cmd.commandParams.push(group.GroupName);
                        cmd.commandParams.push("group:" + groupAuthorization.Name + ":groups");

                        sqlite.getGroupUsers(groupname, function (err, result) {
                            if (!err && result && result.users) {

                                var users = result.users.split(',');
                                // constructor group user's authority.
                                // true if authority is administrator; otherwise, false
                                for (var j = 0; j < users.length; j++) {

                                    var userId = users[j].trim();
                                    // administrator authority priority
                                    if (!groupUserAuthority[userId]) {
                                        groupUserAuthority[userId] = groupAuthority[groupname];
                                    }
                                }
                            }
                            callback(null, cmd);
                        });
                    }, function (err, cmd) {
                        // new group user's authority, update cassandra 
                        for (var userId in groupUserAuthority) {

                            // current user not share, the user group which it's belong have administrator authority
                            if (userAuthority[userId] === undefined && originalGroupUserAuthority[userId]) {

                                var index = originalGroupUserAuthority[userId].indexOf(groupUserAuthority[userId]);
                                if (index >= 0) {

                                    originalGroupUserAuthority[userId].splice(index, 1);

                                    if (originalGroupUserAuthority[userId].length == 0) {

                                        cmd.commandline += " DELETE ? FROM " + config.cassandra.columnFamily + " WHERE KEY = ? ";
                                        cmd.commandParams.push(groupAuthorization.Name);
                                        cmd.commandParams.push("user:" + userId);

                                    } else {

                                        cmd.commandline += " INSERT INTO " + config.cassandra.columnFamily + " (KEY, ?) VALUES (?, ?) ";
                                        cmd.commandParams.push(groupAuthorization.Name);
                                        cmd.commandParams.push("user:" + userId);

                                        if (originalGroupUserAuthority[userId].indexOf(true) >= 0) {
                                            cmd.commandParams.push(false);
                                        } else {
                                            cmd.commandParams.push(true);
                                        }
                                    }
                                }
                            }
                        }

                        cmd.commandline += " APPLY BATCH;";
                        pool.cql(cmd.commandline, cmd.commandParams, function (err, result) {
                            if (err) {
                                util.error(err);
                                cb({ StatusCode: 500 });
                            }
                            else {
                                cb({ StatusCode: 200 });
                            }
                        });
                    });
                });
            });
        });
    } else {
        cb({ StatusCode: 500 });
    }
}

exports.setResource = function (serverName, resourceName, resources) {
    serverName = (serverName || '').toLowerCase();
    resourceName = (resourceName || '').toLowerCase();
    if (resources) {
        pool.cql("INSERT INTO " + config.cassandra.columnFamily + " (KEY, ?) VALUES (?, ?) ", [resourceName, serverName, JSON.stringify(resources)], function (err, rows) {

        });
    }
}

exports.getResource = function (serverName, resourceName, cb) {
    serverName = (serverName || '').toLowerCase();
    resourceName = (resourceName || '').toLowerCase();
    pool.cql("SELECT ? FROM " + config.cassandra.columnFamily + " WHERE KEY = ? ", [resourceName, serverName], function (err, rows) {
        if (err || rows.length == 0 || rows[0].length == 0 || rows[0][0].value === undefined) {
            cb(undefined);
        } else {
            cb(JSON.parse(rows[0][0].value));
        }
    });
}
//end added

exports.getDisks = function (diskInfo, cb) {
    var options = {
        hostname: diskInfo.ServerName,
        port: diskInfo.ServerPort,
        path: diskInfo.Type == 'FILE' ? 'file' : 'dir' + diskInfo.Path + "?" + new Date().toUTCString(),
        method: 'GET'
    };

    var req = http.get(options, function (res) {
        cb();
    });

    req.end();
}

exports.addModule = function (module, cb) {

    if (module && module.GroupName && module.ServerName && module.ModuleType && module.Name) {
        pool.cql("SELECT managementPort,? FROM " + config.cassandra.columnFamily + " WHERE KEY = ? ", [module.GroupName, module.ServerName], function (err, row) {
            if (err || row.length == 0) {
                if (err) util.error(err);
                cb({
                    StatusCode: 500
                });
            }
            else {

                var cols = row[0];

                for (var i = 0; i < cols.length; i++) {

                    var serverCol = cols[i];

                    if (module.GroupName == serverCol.name) {
                        var configObj = JSON.parse(serverCol.value);
                        var exists = false;

                        if (module.ModuleType == 'Job') {

                            if (configObj.Jobs) {
                                for (var j = 0; j < configObj.Jobs.length; j++) {

                                    if (configObj.Jobs[j].Name == module.Name) {
                                        exists = true;
                                        break;
                                    }
                                }
                            } else configObj.Jobs = [];

                            if (exists == false) {
                                configObj.Jobs.push({ Description: module.Description, Interval: module.Interval, Listen: module.Listen, Name: module.Name });
                            }

                        } else if (module.ModuleType == 'Web') {
                            if (configObj.Webs) {
                                for (var k = 0; k < configObj.Webs.length; k++) {
                                    if (configObj.Webs[k].Name == module.Name) {
                                        exists = true;
                                        break;
                                    }
                                }
                            } else configObj.Webs = [];

                            if (exists == false) {
                                configObj.Webs.push({ Description: module.Description, Interval: module.Interval, Listen: module.Listen, Name: module.Name, URI: module.URI, ValidType: module.ValidType, ValidValue: module.ValidValue });
                            }
                        }

                        if (exists == false) {
                            pool.cql("INSERT INTO " + config.cassandra.columnFamily + " (KEY,?) VALUES (?,?) USING CONSISTENCY LOCAL_QUORUM", [module.GroupName, module.ServerName, JSON.stringify(configObj)], function (err, result) {
                                if (err && cb) {
                                    module.StatusCode = 500;
                                    cb(module);
                                }
                                else if (cb) {
                                    module.StatusCode = 200;
                                    cb(module);
                                    var server = buildServerInfo(module.GroupName, module.ServerName, cols);
                                    util.postServerConfig(server.IP || server.Name, server.ManagementPort, { Action: 'Add', Interval: server.Interval, Modules: [module] }, null);
                                }
                            });
                        } else if (cb) {
                            module.StatusCode = 403;
                            cb(module);
                        }
                        break;
                    }
                }
            }
        });
    } else if (cb) {
        cb({
            StatusCode: 500
        });
    }
}

exports.updateModule = function (module, cb) {
    if (module && module.GroupName && module.ServerName && module.ModuleType && module.Name) {
        pool.cql("SELECT managementPort,? FROM " + config.cassandra.columnFamily + " WHERE KEY = ? ", [module.GroupName, module.ServerName], function (err, row) {
            if (err || row.length == 0) {
                if (err) util.error(err);
                cb({
                    StatusCode: 500
                });
            }
            else {
                var cols = row[0];

                for (var i = 0; i < cols.length; i++) {

                    var serverCol = cols[i];

                    if (module.GroupName == serverCol.name) {
                        var configObj = JSON.parse(serverCol.value);

                        var exists = false;
                        var oldModule = null;

                        if (module.ModuleType == 'Job') {
                            if (configObj.Jobs) {
                                for (var j = 0; j < configObj.Jobs.length; j++) {
                                    var job = configObj.Jobs[j];
                                    if (job.Name == module.Name) {
                                        oldModule = { Name: job.Name, ModuleType: 'Job', Interval: job.Interval, Listen: job.Listen, Description: job.Description };
                                        job.Interval = module.Interval;
                                        job.Listen = module.Listen;
                                        job.Description = module.Description;
                                        break;
                                    }
                                }
                            } else configObj.Jobs = [];

                            if (oldModule == null) {
                                oldModule = {};
                                configObj.Jobs.push({ Description: module.Description, Interval: module.Interval, Listen: module.Listen, Name: module.Name });
                            }

                        } else if (module.ModuleType == 'Web') {
                            if (configObj.Webs) {
                                for (var k = 0; k < configObj.Webs.length; k++) {
                                    var web = configObj.Webs[k];
                                    if (web.Name == module.Name) {
                                        oldModule = { Name: web.Name, ModuleType: 'Web', Interval: web.Interval, Listen: web.Listen, Description: web.Description, URI: web.URI, ValidType: web.ValidType, ValidValue: web.ValidValue };
                                        web.Interval = module.Interval;
                                        web.Listen = module.Listen;
                                        web.URI = module.URI;
                                        web.ValidType = module.ValidType;
                                        web.ValidValue = module.ValidValue;
                                        web.Description = module.Description;
                                        break;
                                    }
                                }
                            } else configObj.Webs = [];

                            if (oldModule == null) {
                                oldModule = {};
                                configObj.Webs.push({ Description: module.Description, Interval: module.Interval, Listen: module.Listen, Name: module.Name, URI: module.URI, ValidType: module.ValidType, ValidValue: module.ValidValue });
                            }
                        }

                        if (oldModule) {
                            pool.cql("INSERT INTO " + config.cassandra.columnFamily + " (KEY,?) VALUES (?,?) USING CONSISTENCY LOCAL_QUORUM", [module.GroupName, module.ServerName, JSON.stringify(configObj)], function (err, result) {

                                if (err && cb) {
                                    cb({
                                        StatusCode: 500
                                    })
                                }
                                else if (cb) {
                                    cb({
                                        StatusCode: 200
                                    });
                                    var server = buildServerInfo(module.GroupName, module.ServerName, cols);
                                    if (oldModule.Name) {
                                        util.postServerConfig(server.IP || server.Name, server.ManagementPort, { Action: 'Delete', Interval: server.Interval, Modules: [oldModule] }, null);
                                    }
                                    util.postServerConfig(server.IP || server.Name, server.ManagementPort, { Action: 'Update', Interval: server.Interval, Modules: [module] }, null);
                                }
                            });
                        }
                        break;
                    }
                }
            }
        });
    } else if (cb) {
        cb({
            StatusCode: 500
        });
    }
}

exports.deleteModule = function (module, cb) {
    if (module && module.GroupName && module.ServerName && module.ModuleType && module.Name) {
        pool.cql("SELECT managementPort,? FROM " + config.cassandra.columnFamily + " WHERE KEY = ? ", [module.GroupName, module.ServerName], function (err, row) {
            if (err || row.length == 0) {
                if (err) util.error(err);
                cb({
                    StatusCode: 500
                });
            }
            else {
                var cols = row[0];

                for (var i = 0; i < cols.length; i++) {

                    var serverCol = cols[i];

                    if (module.GroupName == serverCol.name) {
                        var configObj = JSON.parse(serverCol.value);


                        if (module.ModuleType == 'Job' && configObj.Jobs) {
                            var jobs = [];
                            for (var j = 0; j < configObj.Jobs.length; j++) {
                                var job = configObj.Jobs[j];
                                if (job.Name != module.Name) {
                                    jobs.push(job);
                                }
                            }
                            configObj.Jobs = jobs;


                        } else if (module.ModuleType == 'Web' && configObj.Webs) {
                            var webs = [];
                            for (var k = 0; k < configObj.Webs.length; k++) {
                                var web = configObj.Webs[k];
                                if (web.Name != module.Name) {
                                    webs.push(web);
                                }
                            }
                            configObj.Webs = webs;
                        }

                        pool.cql("INSERT INTO " + config.cassandra.columnFamily + " (KEY,?) VALUES (?,?) USING CONSISTENCY LOCAL_QUORUM", [module.GroupName, module.ServerName, JSON.stringify(configObj)], function (err, result) {

                            if (err) {
                                module.StatusCode = 500;
                                cb(module);
                            }
                            else {
                                module.StatusCode = 200;
                                cb(module);
                                var server = buildServerInfo(module.GroupName, module.ServerName, cols);
                                util.postServerConfig(server.IP || server.Name, server.ManagementPort, { Action: 'Delete', Interval: server.Interval, Modules: [module] }, null);
                            }

                        });
                        break;
                    }
                }
            }
        });
    } else if (cb) {
        cb({
            StatusCode: 500
        });
    }
}

exports.refershConfig = function () {
    delete require.cache[require.resolve('./config')];
    config = require('./config');
};

exports.getTaskInfo = function (serverName, cb) {
    pool.cql("SELECT managementPort,cache FROM " + config.cassandra.columnFamily + " WHERE key = ?", [serverName], function (err, serverRow) {
        if (err) {
            util.error(err);
            cb({ StatusCode: 500 });
        }
        else if (serverRow.length >= 1) {
            var serverCols = serverRow[0];
            var server = {};
            for (var i = 0; i < serverCols.length; i++) {

                var serverCol = serverCols[i];

                if ('cache' == serverCol.name && serverCol.value) {
                    server.Cache = JSON.parse(serverCol.value);
                } else if ('managementPort' == serverCol.name) {
                    server.ManagementPort = serverCol.value;
                }
            }

            if (server.Cache) {
                cb(server.Cache.Tasks);
            } else {
                cb({ StatusCode: 500 });
            }
        }
    })
}

//added by benjamin.c.yan 
//2013-08-14 14:00:00
function retrieveCache(serverName, cb, fn) {
    pool.cql("SELECT managementPort,cache FROM " + config.cassandra.columnFamily + " WHERE key = ?", [serverName], function (err, serverRow) {
        if (err) {
            util.error(err);
            cb({ StatusCode: 500 });
        }
        else if (serverRow.length >= 1) {
            var serverCols = serverRow[0];
            var server = {};
            for (var i = 0; i < serverCols.length; i++) {

                var serverCol = serverCols[i];

                if ('cache' == serverCol.name && serverCol.value) {
                    server.Cache = JSON.parse(serverCol.value);
                } else if ('managementPort' == serverCol.name) {
                    server.ManagementPort = serverCol.value;
                }
            }

            if (server.Cache) {
                cb(fn(server.Cache));
            } else {
                cb({ StatusCode: 500 });
            }
        }
    })
}

exports.getSitesInfo = function (serverName, cb) {
    retrieveCache(serverName, cb, function (cache) { return cache.Sites; });
};

exports.getServicesInfo = function (serverName, cb) {
    retrieveCache(serverName, cb, function (cache) { return cache.Services; });
};
//end added

exports.init = function (cb) {
    pool = getCassandraClient();
    pool.on('error', function (err) {
        util.error('server center', err);
    });

    pool.connect(function (err, keyspace) {
        cb(err);
    });
};
