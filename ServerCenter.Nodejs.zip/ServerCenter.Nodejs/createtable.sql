CREATE TABLE IF NOT EXISTS domain_user (
    shortname varchar(20),
    displayname varchar(40),
    groups varchar(1000),
    CONSTRAINT PK_domain_user PRIMARY KEY (shortname ASC)
);

CREATE TABLE IF NOT EXISTS domain_group (
    name varchar(40),
    users TEXT,
    CONSTRAINT PK_domain_group PRIMARY KEY (name ASC)
);