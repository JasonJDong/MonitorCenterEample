exports.users = [
    { userid: 'by46', displayname: 'Benjamin.C.Yan (mis.cncd02.Newegg) 42152' },
    { userid: 'ry96', displayname: 'Roger.Y.Yan (mis.cncd02.Newegg) 42293' },
    { userid: 'cc3i', displayname: 'Carl.J.Chen (mis.cncd02.Newegg) 42193' },
    { userid: 'bh35', displayname: 'Byron.C.Huang (mis.cncd02.Newegg) 42317' }
];

exports.groups = [
    {
        name: '* gp team mis nesc cncd po',
        users: [
            { userid: 'by46', displayname: 'Benjamin.C.Yan (mis.cncd02.Newegg) 42152' },
            { userid: 'ry96', displayname: 'Roger.Y.Yan (mis.cncd02.Newegg) 42293' },
            { userid: 'cc3i', displayname: 'Carl.J.Chen (mis.cncd02.Newegg) 42193' }]
    }, {
        name: '* gp team mis nesc cncd',
        users: [
            { userid: 'cc3i', displayname: 'Carl.J.Chen (mis.cncd02.Newegg) 42193' }
        ]
    }, {
        name: '* gp club body mechanics cncd',
        users: [
            { userid: 'cc3i', displayname: 'Carl.J.Chen (mis.cncd02.Newegg) 42193' },
            { userid: 'by46', displayname: 'Benjamin.C.Yan (mis.cncd02.Newegg) 42152' },
            { userid: 'bh35', displayname: 'Byron.C.Huang (mis.cncd02.Newegg) 42317' }
        ]
    }
];