var express = require('express');
var app = express();
var config = require('./config');
var mimemap = require('./mimemap');
var http = require('http');
var path = require('path');
var fs = require('fs');
var agent = require('agentkeepalive');
var util = require('./util');
var BufferHelper = require('bufferhelper');
var sqlite = require('./sqliteutil');

var keepAgent = new agent({
    maxSockets: 512,
    maxKeepAliveTime: 0
});

app.configure(function () {
    if (config.expressloglevel == 'dev') app.use(express.logger(config.expressloglevel));
    app.use(express.bodyParser());
    app.use(express.errorHandler({
        dumpExceptions: true,
        showStack: true
    }));
});

var dao = require('./dao');

function returnReponse(res, result) {
    if (result) res.end(JSON.stringify(result));
    else res.end();
}

function encode(urlPath) {
    urlPath = urlPath.replace(/\\/g, '/');
    var paths = urlPath.split('/');
    var result = '/';
    for (var i = 0; i < paths.length; i++) {
        if (paths[i]) {
            result = path.join(result, encodeURIComponent(paths[i]));
        }
    }
    return result.replace(/\\/g, '/');
}


app.get('/MonitorCenterDataCenter/Groups/:userID', function (req, res) {
    dao.getServers(req.params.userID, function (result) { returnReponse(res, result) });
});

app.post('/MonitorCenterDataCenter/Groups', function (req, res) {
    dao.addGroup(req.body, function (result) { returnReponse(res, result) });
});

app.delete('/MonitorCenterDataCenter/Groups', function (req, res) {
    dao.deleteGroup(req.body, function (result) { returnReponse(res, result) });
});

app.post('/MonitorCenterDataCenter/Servers', function (req, res) {
    dao.addServer(req.body, function (result) { returnReponse(res, result) });
});

app.delete('/MonitorCenterDataCenter/Servers', function (req, res) {
    dao.deleteServer(req.body, function (result) { returnReponse(res, result) });
});

app.put('/MonitorCenterDataCenter/Servers', function (req, res) {
    dao.updateServer(req.body, function (result) { returnReponse(res, result) });
});

app.get('/MonitorCenterDataCenter/GroupAuthorization/:userID', function (req, res) {
    dao.getGroupAuthorization(req.params.userID, function (result) { returnReponse(res, result) });
});

app.put('/MonitorCenterDataCenter/GroupAuthorization', function (req, res) {
    dao.updateGroupAuthorization(req.body, function (result) { returnReponse(res, result) });
});

app.delete('/MonitorCenterDataCenter/GroupAuthorization', function (req, res) {
    dao.deleteGroupAuthorization(req.body, function (result) { returnReponse(res, result) });
});

//added by benjamin.c.yan
//2013-08-16 15:00:00
//description: share group by usergroup
app.get('/MonitorCenterDataCenter/GroupAuthorizationByUserGroup/:userID', function (req, res) {
    dao.getGroupAuthorizationByUserGroup(req.params.userID, function (result) { returnReponse(res, result) });
});

app.put('/MonitorCenterDataCenter/GroupAuthorizationByUserGroup', function (req, res) {
    dao.updateGroupAuthorizationByUserGroup(req.body, function (result) { returnReponse(res, result) });
});

app.delete('/MonitorCenterDataCenter/GroupAuthorizationByUserGroup', function (req, res) {
    dao.deleteGroupAuthorizationByUserGroup(req.body, function (result) { returnReponse(res, result) });
});

//end added

app.post('/MonitorCenterDataCenter/Modules', function (req, res) {
    dao.addModule(req.body, function (result) { returnReponse(res, result) });
});

app.delete('/MonitorCenterDataCenter/Modules', function (req, res) {
    dao.deleteModule(req.body, function (result) { returnReponse(res, result); });
});

app.put('/MonitorCenterDataCenter/Modules', function (req, res) {
    dao.updateModule(req.body, function (result) { returnReponse(res, result) });
});

app.get('/MonitorCenterDataCenter/Disks/*', function (req, res) {
    var url = req.url.replace('/MonitorCenterDataCenter/Disks/', '');
    url = new Buffer(url, 'base64').toString();
    var urls = url.split('/');
    var filename = encode(urls[urls.length - 1]).substring(1);
    res.setHeader('Content-Type', mimemap.findMIME(filename));
    res.setHeader("content-disposition", "filename=" + filename);

    var removeString = urls[1] + '/' + urls[2] + '/' + urls[3] + '/';
    var url = '/' + urls[3].toLowerCase() + url.replace(removeString, '');

    var options = {
        agent: keepAgent,
        host: urls[1],
        port: urls[2],
        path: encode(url),
        headers: { Authorization: config.authorization }
    };

    var request = http.get(options, function (response) {
        if (response.statusCode == 200) {
            response.on('data', function (chunk) {
                res.write(chunk);
            });

            response.once('end', function () {
                res.end();
            });
        } else {
            res.end();
        }
    });

    request.on('error', function (e) {
        res.end();
    });

    request.setTimeout(5000, function () {
        res.end();
    });

    request.end();
});


app.post('/MonitorCenterDataCenter/Disks', function (req, res) {

    var url = req.body ? '/dir' + req.body.Path : '/dir';

    var options = {
        agent: keepAgent,
        host: req.body.ServerName,
        port: req.body.ServerPort,
        path: encode(url) + '/',
        headers: { Authorization: config.authorization }
    };

    var request = http.get(options, function (response) {
        if (response.statusCode == 200) {
            response.on('data', function (chunk) {
                res.write(chunk);
            });

            response.once('end', function () {
                res.end();
            });
        } else {
            res.end();
        }
    });

    request.on('error', function (e) {
        res.end();
    });

    request.setTimeout(5000, function () {
        res.end();
    });

    request.end();

});

app.get('/MonitorCenterDataCenter/Tasks/:serverName', function (req, res) {
    dao.getTaskInfo(req.params.serverName, function (result) { returnReponse(res, result) });
});

//add by benjamin.c.yan
// 2013-08-06 15:30
app.get('/MonitorCenterDataCenter/Resource/:resourceType/:serverName/:serverPort/:refresh', function (req, res) {

    var serverName = req.params.serverName;
    var serverPort = req.params.serverPort;
    var resourceName = req.params.resourceType.toLowerCase();
    var refresh = req.params.refresh.toLowerCase() === 'true';
    res.setHeader('Content-Type:Application/json');

    if (!refresh) {
        dao.getResource(serverName, resourceName, function (resources) {
            if (resources) {
                returnReponse(res, resources);
            } else {
                retrieveResource(serverName, serverPort, resourceName, function (result) {
                    if (result) {
                        returnReponse(res, result);
                        dao.setResource(serverName, resourceName, result);
                    } else {
                        returnReponse(res, []);
                    }
                });
            }
        });
    } else {
        retrieveResource(serverName, serverPort, resourceName, function (result) {
            if (result) {
                returnReponse(res, result);
                dao.setResource(serverName, resourceName, result);
            } else {
                returnReponse(res, []);
            }
        });
    }
});

function retrieveResource(serverName, serverPort, resourceName, cb) {
    var resources = { 'sites': '/sites/', 'services': '/services/' };
    var options = {
        agent: keepAgent,
        host: serverName,
        port: serverPort,
        path: resources[resourceName],
        headers: { Authorization: config.authorization }
    };
    var buffer = new BufferHelper();
    var result = undefined;
    var request = http.get(options, function (response) {
        if (response.statusCode == 200) {
            response.on('data', function (chunk) {
                buffer.concat(chunk);
            });

            response.once('end', function () {
                try {
                    result = JSON.parse(buffer.toBuffer().toString());
                } catch (err) {
                    // deal with error
                }
                cb(result);
            });
        } else {
            cb(result);
        }

        request.on('error', function (e) {
            cb(result);
        });

        request.setTimeout(60000, function () {
            cb(result);
        });

        request.end();
    });
};
//end add

app.get('/MonitorCenterDataCenter/DomainGroupInfo/:group', function (req, res) {
    sqlite.getGroupByName(req.params.group, function (err, result) { returnReponse(res, result); });
});

app.get('/MonitorCenterDataCenter/DomainUserInfo/:user', function (req, res) {
    util.sqliteutil.getUserByName(req.params.user, function (err, result) { returnReponse(res, result); });
});

app.get('/*', function (req, res) {
    var filePath = path.join(__dirname, req.url);
    fs.exists(filePath, function (exists) {
        if (exists) {
            fs.readFile(filePath, function (err, data) {
                if (err) {
                    res.statusCode = 500;
                    res.end();
                } else {
                    res.setHeader('Content-Length', data.length);
                    res.end(data);
                }
            });
        } else {
            res.statusCode = 404;
            res.setHeader('Content-Length', 0);
            res.end();
        }
    });
});

exports.start = function () {
    dao.init(function (err) {
        if (err) util.error(err);
        else {
            app.listen(config.monitorServerPort);
            util.info('monitor sever center (', process.pid, ') listening on', config.monitorServerPort);
            fs.watch(path.join(__dirname, 'config.js'), function (event, filename) {
                delete require.cache[require.resolve('./config')];
                config = require('./config');
                dao.refershConfig();
            });
        }
    });
}
