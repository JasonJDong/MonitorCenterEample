require("mkdirp").sync('logs');

var util = require('./util');
var cluster = require('cluster');
var monitorcenterserver = require('./monitorcenterserver');
var sqliteutil = require('./sqliteutil');
var sqlite = require('sqlite3').verbose();

var fs = require('fs');
var dao = require('./dao');

var os = require('os');
var numCPUs = os.cpus().length;

process.on("uncaughtException", function (err) {
    util.error("server center uncaughtException : ", err.message, "\n type:", err.type, "\n arguments:", typeof (err.arguments), "\n stack: ", err.stack);
    process.exit();
});


if (cluster.isMaster) {

    var dbclient = new sqlite.Database(":memory:");
    util.sqliteutil.installdb(dbclient, function (success) {

    });
    for (var i = 0; i < numCPUs; i++) {
        cluster.fork();
    }

    cluster.on('exit', function (worker) {
        cluster.fork();
    });

} else {
    monitorcenterserver.start();
}