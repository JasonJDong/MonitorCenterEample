var sqlite = require('sqlite3').verbose();
var fs = require('fs');
var util = require('./util');
var request = require('request');
var path = require('path');
var config = require('./config');

var userdata = path.join(__dirname, 'alluser.data');
var backupdata = path.join(__dirname, 'domaindata.db');
var createSql = path.join(__dirname, 'createtable.sql');

//var dbclient = new sqlite.Database(":memory:");
var dbclient = null;
var dbackupClient = new sqlite.Database(backupdata);
var apiUri = config.doaminAPI;
var isProcess = false;
var forcebackup = false;
var needUpdateBackup = false;

function opendb(callback) {
    try {
        console.log("opendb");

        fs.readFile(createSql, "utf8", function (err, data) {
            if (err) {
                console.log(err);
            }
            dbclient.exec(data, function (createerr) {
                if (!createerr) {
                    console.log("readFile");
                    mem_user_groups = [];
                    mem_user_groups_name = [];
                    callback(true, true);
                }
            });
        });

    } catch (e) {
        console.log(e);
        callback(false, true);
    }
}

function syncDomainUserGroups(users, callback) {
    if (users != undefined) {
        dbclient.exec("DELETE FROM domain_group");
        dbclient.exec("DELETE FROM domain_user");
        var userJson = JSON.parse(users);
        console.log("syncDomainUserGroups");
        getUserGroupsFromAPI(userJson, function () {
            try {
                var stmt = dbclient.prepare("INSERT INTO domain_user(shortname,displayname,groups) VALUES(?,?,?)");
                for (var i = 0; i < mem_user_groups.length; i++) {
                    for (var j = 0; j < mem_user_groups[i].Groups.length; j++) {
                        var currGroups = mem_user_groups[i].Groups[j];
                        if (currGroups != undefined) {
                            pushDataInMemory(currGroups.replace("'", ""), mem_user_groups[i].UserName);
                        }
                    }
                    stmt.run([mem_user_groups[i].UserName, mem_user_groups[i].DisplayName, mem_user_groups[i].Groups.toString()]);
                }
                console.log("insert user" + mem_user_groups.length);
                stmt.finalize(updateGroup);
                callback(null);
            } catch (e) {
                callback(e);
            }
        });
    } else {
        callback(null);
    }
}

var mem_groups = [];
var mem_group_name = [];
function updateGroup() {

    var insert = dbclient.prepare("INSERT INTO domain_group(name,users) VALUES(?,?)");

    for (var i = 0; i < mem_groups.length; i++) {
        insert.run([mem_groups[i].Group, mem_groups[i].User]);
    }
    console.log("insert group" + mem_groups.length);
    if (needUpdateBackup) {
        insert.finalize(updatebackup);
    } else {
        insert.finalize();
    }
    mem_groups = [];
    mem_group_name = [];
}

function pushDataInMemory(group, user) {
    var group_user = { Group: group.toLowerCase(), User: user };

    if (mem_group_name.indexOf(group) < 0) {
        mem_group_name.push(group);
        mem_groups.push(group_user);
    } else {
        try {
            var index = mem_group_name.indexOf(group);
            var item = mem_groups[index];
            var existsUser = item.User;
            var existsUserArray = existsUser.split(',');
            if (existsUserArray.indexOf(user) < 0) {
                existsUserArray.push(user);
            }
            var existsUserString = existsUserArray.join(',');
            mem_groups[index].User = existsUserString;
        } catch (e) {
        }
    }
}

//function getAllUsers(callback) {
//    var queryUsers = apiUri + 'user?format=json';
//    request(queryUsers, function (err, response, body) {
//        if (err) callback(undefined);
//        if (response.statusCode == 200) {
//            callback(body);
//        } else {
//            callback(undefined);
//        }
//    });
//}
function getAllUsers(callback) {
    fs.readFile("C:\\Users\\jd29\\Desktop\\alluser.txt", "utf8", function (err, data) {
        callback(data);
    });
}

var mem_user_groups = [];
var mem_user_groups_name = [];
function getUserGroupsFromAPI(userJson, callback) {
    var counter = userJson.length;
    for (var i = 0; i < userJson.length; i++) {
        var username = userJson[i].UserName;
        var queryUser = apiUri + 'user/' + username + '?format=json';
        request(queryUser, function (err, response, body) {
            if (!err && response.statusCode == 200) {
                var dataJson = JSON.parse(body);
                if (dataJson.Groups != undefined) {
                    var user_groups = { UserName: dataJson.UserName, DisplayName: dataJson.DisplayName, Groups: dataJson.Groups };
                    mem_user_groups.push(user_groups);
                    if (!isExistsUser(dataJson.UserName)) {
                        mem_user_groups_name.push(dataJson.UserName);
                    }
                } else {
                    var user_groups_undefined = { UserName: dataJson.UserName, DisplayName: dataJson.DisplayName, Groups: [] };
                    mem_user_groups.push(user_groups_undefined);
                    if (!isExistsUser(dataJson.UserName)) {
                        mem_user_groups_name.push(dataJson.UserName);
                    }
                }
            }
            if (--counter <= 0) {
                callback();
            }
        });
    }
}

function isExistsUser(userName) {
    if (mem_user_groups_name.length > 0) {
        return mem_user_groups_name.indexOf(userName) > -1;
    } else {
        return false;
    }
}


function closeDb() {
    dbclient.close();
}

function process(callback) {
    isProcess = true;
    opendb(function (success, nodata) {
        if (success == true) {
            getAllUsers(function (users) {
                if (users) {
                    fs.exists(userdata, function (exists) {
                        if (exists) {
                            fs.readFile(userdata, "utf8", function (err, data) {
                                var oldusermd5 = util.md5(data);
                                var nowusermd5 = util.md5(users);
                                var md5equal = oldusermd5 === nowusermd5;
                                //needUpdateBackup = !md5equal;
                                needUpdateBackup = false;
                                if (md5equal && !nodata) {
                                    isProcess = false;
                                    callback(true);
                                } else {
                                    genquerydata(users, function (gen) {
                                        callback(gen);
                                    });
                                }
                            });
                        } else {
                            genquerydata(users, function (gen) {
                                callback(gen);
                            });
                        }
                    });
                } else {
                    isProcess = false;
                    console.log("dbclient set null");
                    dbclient = null;
                    callback(false);
                }
            });
        } else {
            isProcess = false;
            console.log("dbclient set null");
            dbclient = null;
            callback(false);
        }
    });
}

function genquerydata(users, callback) {
    fs.writeFile(userdata, users, function (newusererr) {
        if (newusererr) {
            util.error("write users data error : ", newusererr.message, newusererr.type, "\n arguments: ", typeof (newusererr.arguments), "\n stack: ", err.stack);
        }
    });
    syncDomainUserGroups(users, function (syncerr) {
        syncfinished(syncerr, function (finish) {
            isProcess = false;
            console.log("syncfinished");
            callback(finish);
        });
    });
}

function syncfinished(err, callback) {
    config.domaindatalastupdate = new Date();
    if (err) {
        util.error("sqlite synchronize error: ", err.message, "\n type:", err.type, "\n arguments:", typeof (err.arguments), "\n stack: ", err.stack);
        console.log("dbclient set null");

        dbclient = null;
        callback(false);
    } else {
        callback(true);
    }
}

function updatebackup() {
    try {
        dbackupClient.exec("DELETE FROM domain_group");
        dbackupClient.exec("DELETE FROM domain_user");

        dbclient.all("SELECT * FROM domain_user", function (err, rows) {
            if (!err && rows && rows.length > 0) {
                var stmt = dbackupClient.prepare("INSERT INTO domain_user(shortname,displayname,groups) VALUES(?,?,?)");
                for (var i = 0; i < rows.length; i++) {
                    stmt.run([rows[i].shortname, rows[i].displayname, rows[i].groups]);
                }
                stmt.finalize();
            }
        });

        dbclient.all("SELECT * FROM domain_group", function (err, rows) {
            if (!err && rows && rows.length > 0) {
                var stmt = dbackupClient.prepare("INSERT INTO domain_group(name,users) VALUES(?,?)");
                for (var i = 0; i < rows.length; i++) {
                    stmt.run([rows[i].name, rows[i].users]);
                }
                stmt.finalize();
            }
        });
    } catch (e) {
        console.log(e);
    }
}

exports.installdb = function (client, callback) {
    console.log("installdb");
    dbclient = client;
    if (config.domaindatalastupdate == undefined) {
        config.domaindatalastupdate = new Date();
        if (!isProcess) {
            process(function (success) {
                callback(success);
            });
        }
    }
    var sqliteUpdateOption = config.sqliteUpdateOption;
    var syncsqliteinternal = sqliteUpdateOption.syncsqliteinternal;
    var checksqliteinternal = sqliteUpdateOption.checksqliteinternal;
    var processmintime = sqliteUpdateOption.processmintime;
    var processmaxtime = sqliteUpdateOption.processmaxtime;

    if (syncsqliteinternal == undefined || syncsqliteinternal == null) {
        syncsqliteinternal = 86400000;
    }
    if (checksqliteinternal == undefined || checksqliteinternal == null) {
        checksqliteinternal = 14400000;
    }
    if (processmintime == undefined || processmintime == null) {
        processmintime = 0;
    }
    if (processmaxtime == undefined || processmaxtime == null) {
        processmaxtime = 4;
    }
    setInterval(function () {

        var night = new Date().getHours();
        var day = ((new Date()).getTime() - config.domaindatalastupdate.getTime()) / syncsqliteinternal;
        if (day >= 1 && night >= processmintime && night <= processmaxtime) {
            if (!isProcess) {
                process(function (success) {
                    callback(success);
                });
            }
        }
    }, checksqliteinternal);
};

exports.getUserGroups = function (userID, callback) {
    var client = isProcess || dbclient == null || forcebackup ? dbackupClient : dbclient;
    client.get("SELECT groups FROM domain_user WHERE shortname = ?", [userID], function (err, result) {
        if (result != undefined) {
            callback(err, result);
        } else {
            callback(err, null);
        }
    });
};

exports.getUserDisplayName = function (userID, callback) {
    var client = isProcess || dbclient == null || forcebackup ? dbackupClient : dbclient;
    client.get("SELECT displayname FROM domain_user WHERE shortname = ?", [userID], function (err, result) {
        if (result != undefined) {
            callback(err, result);
        } else {
            callback(err, null);
        }
    });
};

exports.getGroupUsers = function (groupName, callback) {
    var client = isProcess || dbclient == null || forcebackup ? dbackupClient : dbclient;
    client.get("SELECT users FROM domain_group WHERE name = ?", [groupName], function (err, result) {
        if (result != undefined) {
            callback(err, result);
        } else {
            callback(err, null);
        }
    });
};

exports.getGroupByName = function (groupName, callback) {
    var client = isProcess || dbclient == null || forcebackup ? dbackupClient : dbclient;
    client.all("SELECT name FROM " +
        "(SELECT name FROM domain_group WHERE name like '" + groupName + "%' UNION " +
        "SELECT name FROM domain_group WHERE name like '%" + groupName + "') " +
        "ORDER BY name LIMIT 20", function (err, rows) {
            var result = [];
            if (rows != undefined) {
                for (var j = 0; j < rows.length; j++) {
                    result.push({ Name: rows[j].name });
                }
                if (rows.length < 20) {
                    client.all("SELECT name FROM domain_group WHERE name like '%" + groupName + "%' ORDER BY name LIMIT " + (20 - rows.length), function (othererr, otherrows) {
                        if (otherrows != undefined && otherrows.length > 0) {
                            otherrows.forEach(function (otherrow, otherindex, otherthisobject) {
                                var oneGroup = { Name: otherrow.name };
                                var exists = false;
                                for (var i = 0; i < result.length; i++) {
                                    if (result[i].Name == oneGroup.Name) {
                                        exists = true;
                                        break;
                                    }
                                }
                                if (!exists) {
                                    result.push(oneGroup);
                                }
                                if (otherindex == otherthisobject.length - 1) {
                                    callback(null, result);
                                }
                            });
                        } else {
                            callback(null, result);
                        }
                    });
                } else {
                    callback(null, result);
                }
            } else {
                callback(err, null);
            }
        });
};

exports.getUserByName = function (user, callback) {
    //var client = isProcess || dbclient == null || forcebackup ? dbackupClient : dbclient;
    //dbclient.all("SELECT * FROM domain_user", function (err, rows) {
    //    if (rows) {
    //        console.log(rows.length);
    //    } else {
    //        console.log("no record");
    //    }
    //});

    dbclient.all("SELECT shortname,displayname FROM " +
                    "(SELECT shortname,displayname FROM domain_user WHERE displayname like '" + user + "%' OR shortname like '" + user + "%' UNION " +
                    "SELECT shortname,displayname FROM domain_user WHERE displayname like '%" + user + "' OR shortname like '%" + user + "') " +
                    "ORDER BY displayname LIMIT 20", function (err, rows) {
                        var result = [];
                        if (rows != undefined) {
                            for (var j = 0; j < rows.length; j++) {
                                result.push({ ShortName: rows[j].shortname, DisplayName: rows[j].displayname });
                            }
                            if (rows.length < 20) {
                                dbclient.all("SELECT shortname,displayname FROM domain_user WHERE displayname like '%" + user + "%' OR shortname like '%" + user + "%' ORDER BY displayname LIMIT " + (20 - rows.length), function (othererr, otherRows) {
                                    if (otherRows != undefined && otherRows.length > 0) {
                                        otherRows.forEach(function (otherrow, otherindex, otherthisobject) {
                                            var oneUser = { ShortName: otherrow.shortname, DisplayName: otherrow.displayname };
                                            var exists = false;
                                            for (var i = 0; i < result.length; i++) {
                                                if (result[i].ShortName == oneUser.ShortName) {
                                                    exists = true;
                                                    break;
                                                }
                                            }
                                            if (!exists) {
                                                result.push(oneUser);
                                            }
                                            if (otherindex == otherthisobject.length - 1) {
                                                callback(null, result);
                                            }
                                        });
                                    } else {
                                        callback(null, result);
                                    }
                                });
                            } else {
                                callback(null, result);
                            }
                        } else {
                            callback(err, null);
                        }
                    });
};

exports.init = function (dbname, usebackup) {
    backupdata = dbname;
    forcebackup = usebackup;
};

exports.process = process;

var Sqlite = function () {
    Sqlite.prototype.client = new sqlite.Database(":memory:");
    var createSql = path.join(__dirname, 'createtable.sql');
    fs.readFile(createSql, "utf8", function (err, data) {
        if (err) {
            console.log(err);
        } else {
            Sqlite.prototype.client.exec(data, function (createerr) {
                if (!createerr) {
                    console.log("readFile");
                    Sqlite.prototype.client.exec("INSERT INTO domain_user(shortname,displayname,groups) VALUES('jd29','Jason','* gp po')");
                }
            });
        }
    });
    this.getRecord = function () {
        this.client.all("SELECT * FROM domain_user", function (err, rows) {
            if (rows) {
                console.log(rows.length);
            } else {
                console.log("no record");
            }
        });
    };
};
exports.Sqlite = Sqlite;