var helenus = require('helenus');
var config = require('./config');
var async = require('async');
var util = require('./util');

function getCassandraClient() {
    return new helenus.ConnectionPool({
        hosts: config.cassandra.hosts,
        keyspace: config.cassandra.keyspace
    });
};

var pool = getCassandraClient();

pool.on('error', function (err) {
    util.error('cache', err);
});

exports.start = function () {
    var pool = getCassandraClient();
    pool.connect(function (err, keyspace) {
        if (err == undefined) {
            util.info('cache start ...');
            setInterval(function () {
                pool.cql("SELECT * FROM Servers WHERE key = ?", ['servers'], function (err, row) {
                    if (err) {
                        util.error('cache', err);
                    } else if (row.length >= 1) {
                        var cols = row[0];
                        for (var i = 0; i < cols.length; i++) {
                            var serverJSON = JSON.parse(cols[i].value);
                            util.getServerInfo(cols[i].name, serverJSON.IP, serverJSON.Port, function (server) {
                                pool.cql(" INSERT INTO " + config.cassandra.columnFamily + " (KEY, cache) VALUES (?, ?) USING CONSISTENCY LOCAL_QUORUM  AND TTL ?; ", [server.Name, JSON.stringify(server), config.cacheTTL], null);
                            });
                        }
                    }
                });
            }, 5000)
        } else {
            util.error('cache', err);
        }
    })
}