var http = require('http');
var agent = require('agentkeepalive');
var config = require('./config');
var util = require('util');
var path = require('path');
var crypto = require('crypto');

var sqliteutil = require('./sqliteutil');
exports.sqliteutil = sqliteutil;

var keepAgent = new agent({
    maxSockets: 50,
    maxKeepAliveTime: 0
});

var log4js = require('log4js');
log4js.configure(path.join(__dirname, 'log4js_configuration.json'), { reloadSecs: 60, cwd: __dirname });
logger = log4js.getLogger();
var errorLogger = log4js.getLogger('errors');
var infoLogger = log4js.getLogger('infos');

exports.info = function () {
    infoLogger.info(util.format.apply(this, arguments));
}

exports.error = function () {
    errorLogger.error(util.format.apply(this, arguments));
}

exports.md5 = function (str, encoding) {
    return crypto
      .createHash('md5')
      .update(str)
      .digest(encoding || 'hex');
};


function postServerConfig(serverName, port, data, cb) {
    var content = JSON.stringify(data);
    var options = {
        agent: keepAgent,
        host: serverName,
        port: port,
        path: '/configs/',
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Content-Length': content.length }
    };

    var req = http.request(options, function (res) {
        if (cb) cb();
    });

    req.on('error', function (e) {
        if (e.code != 'ETIMEDOUT') {
            if (cb) cb();
        }
    });

    req.setTimeout(config.timeOut, function () {
        if (cb) cb();
        req.destroy();
    });
    req.write(content);
    req.end();
}

function getServerInfo(serverName, serverIP, port, cb) {
    var options = {
        agent: keepAgent,
        host: serverIP || serverName,
        port: port,
        path: '/systemstatus/'
    };

    var req = http.get(options, function (res) {
        if (res.statusCode == 200) {
            var datas = null;
            res.on('data', function (chunk) {
                if (datas == null) datas = chunk;
                else datas += chunk;
            });

            res.once('end', function () {
                var server = {};
                if (datas)
                    server = JSON.parse(datas);

                server.Name = serverName;
                server.ManagementPort = port;
                server.IP = serverIP;
                cb(server);
            });
        } else if (cb) {
            cb({
                Name: serverName,
                ManagementPort: port,
                IP: serverIP
            });
        }
    });

    req.on('error', function (e) {
        if (e.code != 'ETIMEDOUT' && cb) {
            cb({
                Name: serverName,
                ManagementPort: port,
                IP: serverIP
            });
        }
    });

    req.setTimeout(config.timeOut, function () {
        req.destroy();
        if (cb) {
            cb({
                Name: serverName,
                ManagementPort: port,
                IP: serverIP
            });
        }
    });
    req.end();
}

exports.getServerInfo = getServerInfo;
exports.postServerConfig = postServerConfig;