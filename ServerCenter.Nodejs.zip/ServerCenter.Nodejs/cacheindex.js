var cluster = require('cluster');
var monitorcenterserver = require('./monitorcenterserver');
var cache = require('./cache');
var util = require('./util');

process.on("uncaughtException", function (err) {
    util.error("cache uncaughtException : ", err.message, "\n type:", err.type, "\n arguments:", typeof (err.arguments), "\n stack: ", err.stack);
    process.exit();
});

if (cluster.isMaster) {
    cluster.fork();
    cluster.on('exit', function (worker) {
        cluster.fork();
    });
} else {
    cache.start();
}