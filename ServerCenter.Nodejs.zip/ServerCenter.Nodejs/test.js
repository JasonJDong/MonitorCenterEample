var assert = require('assert');
var helenus = require('helenus');
var config = require('./config');

config.cassandra.columnFamily = 'Servers_Test';
config.cassandra.hosts = ['10.16.76.249:9160'];
var path = require('path');

var dao = require('./dao');
var sqlite = require('./sqliteutil.js');
sqlite.init('domaindata_test.db', true);
var sqliteInstallTest = require('./sqliteutil.js');
sqliteInstallTest.init(path.join(__dirname, 'domaindb_install_test.db'), true);
var async = require('async');


var groups = [
           { Name: 'gdev', UserID: 'by46' },
           { Name: 'gqc', UserID: 'by46' }, ];
describe('dao.js', function () {
    var pool = new helenus.ConnectionPool({
        hosts: config.cassandra.hosts,
        keyspace: config.cassandra.keyspace
    });

    before(function (done) {
        this.timeout(10000);
        pool.connect(function (err, keyspace) {
            if (err) {
                throw new Error(err);
            }
            pool.cql("TRUNCATE Servers_Test", [], function (err, result) {
                if (err) {
                    throw new Error(err);
                }
                dao.init(function (err) {
                    if (err) {
                        throw new Error(err);
                    }
                    dao.addGroup({
                        Name: 'testgroup',
                        UserID: 'testuser',
                        Servers: [{
                            Name: 'scmispo01'
                        }, {
                            Name: 'scmispo02'
                        }]
                    }, function (result) {
                        assert.equal(result.StatusCode, 200);
                        done();
                    });
                });
            });
        });
    });

    describe('Group', function () {
        describe('#addGroup()', function () {

            it('Normal', function (done) {

                pool.cql("SELECT * FROM Servers_Test WHERE KEY = ?", ['user:testuser'], function (err, row) {
                    assert.equal(row[0].length, 1);
                    assert.equal(row[0][0].name, 'testgroup');
                    assert.equal(row[0][0].value, "false");
                    pool.cql("SELECT * FROM Servers_Test WHERE KEY = ?", ['group:testgroup'], function (err, row) {
                        assert.equal(row[0].length, 2);
                        assert.equal(row[0][0].name, 'scmispo01');
                        assert.equal(row[0][1].name, "scmispo02");
                        pool.cql("SELECT * FROM Servers_Test WHERE KEY = ?", ['group:testgroup:users'], function (err, row) {
                            assert.equal(row[0].length, 1);
                            assert.equal(row[0][0].name, 'testuser');
                            assert.equal(row[0][0].value, "false");
                            pool.cql("SELECT * FROM Servers_Test WHERE KEY = ?", ['servers'], function (err, row) {
                                assert.equal(row[0].length, 2);
                                assert.equal(row[0][0].name, 'scmispo01');
                                assert.equal(JSON.parse(row[0][0].value).Port, config.managementPort);
                                assert.equal(row[0][1].name, 'scmispo02');
                                assert.equal(JSON.parse(row[0][1].value).Port, config.managementPort);

                                pool.cql("SELECT * FROM Servers_Test WHERE KEY = ?", ['scmispo01'], function (err, row) {
                                    assert.equal(row[0].length, 2);
                                    assert.equal(row[0][0].name, 'managementPort');
                                    assert.equal(row[0][0].value, config.managementPort);
                                    assert.equal(row[0][1].name, 'testgroup');
                                    var configObj = JSON.parse(row[0][1].value);
                                    assert.equal(configObj.ListenServer, true);
                                    assert.equal(configObj.Interval, 5);

                                    pool.cql("SELECT * FROM Servers_Test WHERE KEY = ?", ['scmispo02'], function (err, row) {
                                        assert.equal(row[0].length, 2);
                                        assert.equal(row[0][0].name, 'managementPort');
                                        assert.equal(row[0][0].value, config.managementPort);
                                        assert.equal(row[0][1].name, 'testgroup');
                                        var configObj = JSON.parse(row[0][1].value);
                                        assert.equal(configObj.ListenServer, true);
                                        assert.equal(configObj.Interval, 5);
                                        done();
                                    });
                                });
                            });
                        });
                    });
                });

            });

            it('Exception', function (done) {
                dao.addGroup(null, function (result) {
                    assert.equal(result.StatusCode, 500);
                    dao.addGroup({
                        UserID: 'testuser',
                        Servers: [{
                            Name: 'scmispo01'
                        }, {
                            Name: 'scmispo02'
                        }]
                    }, function (result) {
                        assert.equal(result.StatusCode, 500);
                        dao.addGroup({
                            Name: 'testgroup',
                            Servers: [{
                                Name: 'scmispo01'
                            }, {
                                Name: 'scmispo02'
                            }]
                        }, function (result) {
                            assert.equal(result.StatusCode, 500);
                            dao.addGroup({
                                Name: 'testgroup',
                                UserID: 'testuser'
                            }, function (result) {
                                assert.equal(result.StatusCode, 500);
                                dao.addGroup({
                                    Name: 'testgroup',
                                    UserID: 'testuser',
                                    Servers: [{
                                        Name: 'scmispo01'
                                    }, {}]
                                }, function (result) {
                                    assert.equal(result.StatusCode, 500);
                                    dao.addGroup({
                                        Name: 'testgroup',
                                        UserID: 'testuser',
                                        Servers: [{
                                            Name: 'scmispo01'
                                        }, {
                                            Name: null
                                        }]
                                    }, function (result) {
                                        assert.equal(result.StatusCode, 500);
                                        dao.addGroup({
                                            Name: 'testgroup',
                                            UserID: 'testuser',
                                            Servers: [{
                                                Name: 'scmispo01'
                                            }, {
                                                Name: ''
                                            }]
                                        }, function (result) {
                                            assert.equal(result.StatusCode, 500);
                                            dao.addGroup({
                                                Name: 'testgroup',
                                                UserID: 'testuser',
                                                Servers: [{
                                                    Name: 'scmispo01'
                                                }, {
                                                    Name: 'scmispo02'
                                                }]
                                            }, function (result) {
                                                assert.equal(result.StatusCode, 403);
                                                done();
                                            });
                                        });
                                    });
                                });
                            });
                        });
                    });
                });
            });
        })
        describe('#deleteGroup()', function () {
            this.timeout(30000);
            it('Normal', function (done) {
                dao.deleteGroup({
                    Name: 'testgroup',
                    Servers: [{
                        Name: 'scmispo01'
                    }, {
                        Name: 'scmispo02'
                    }]
                }, function (result) {
                    assert.equal(result.StatusCode, 200);
                    setTimeout(function () {

                        pool.cql("SELECT * FROM Servers_Test WHERE KEY = ?", ['scmispo01'], function (err, row) {
                            assert.equal(row[0].length, 1);
                            assert.equal(row[0][0].name, 'managementPort');
                            pool.cql("SELECT * FROM Servers_Test WHERE KEY = ?", ['scmispo02'], function (err, row) {
                                assert.equal(row[0].length, 1);
                                assert.equal(row[0][0].name, 'managementPort');
                                pool.cql("SELECT * FROM Servers_Test WHERE KEY = ?", ['servers'], function (err, row) {
                                    assert.equal(row[0].length, 0);
                                    pool.cql("SELECT * FROM Servers_Test WHERE KEY = ?", ['user:testuser'], function (err, row) {
                                        assert.equal(row[0].length, 0);
                                        pool.cql("SELECT * FROM Servers_Test WHERE KEY = ?", ['group:testgroup:users'], function (err, row) {
                                            assert.equal(row[0].length, 0);
                                            pool.cql("SELECT * FROM Servers_Test WHERE KEY = ?", ['group:testgroup'], function (err, row) {
                                                assert.equal(row[0].length, 0);
                                                done();
                                            });
                                        });
                                    });
                                });
                            });
                        });

                    }, 20000);
                });
            });

            it('Exception', function (done) {
                dao.deleteGroup(null, function (result) {
                    assert.equal(result.StatusCode, 500);
                    dao.deleteGroup({
                        Servers: [{
                            Name: 'scmispo01'
                        }, {
                            Name: 'scmispo02'
                        }]
                    }, function (result) {
                        assert.equal(result.StatusCode, 500);
                        done();
                    });
                });
            });
        })
    })

    describe('Server', function () {
        before(function (done) {
            dao.addGroup({
                Name: 'testgroup',
                UserID: 'testuser',
                Servers: [{
                    Name: 'scmispo01'
                }]
            }, function (result) {
                assert.equal(result.StatusCode, 200);
                dao.addGroup({
                    Name: 'testgroup_2',
                    UserID: 'testuser',
                    Servers: [{
                        Name: 'scmispo01'
                    }]
                }, function (result) {
                    assert.equal(result.StatusCode, 200);
                    done();
                });
            });
        });
        describe('#addServer()', function () {
            it('Normal', function (done) {
                dao.addServer({
                    Name: 'wcmis073',
                    GroupName: 'testgroup'
                }, function (result) {
                    assert.equal(result.StatusCode, 200);

                    pool.cql("SELECT * FROM Servers_Test WHERE KEY = ?", ['servers'], function (err, row) {
                        assert.equal(row[0].length, 2);
                        assert.equal(row[0][0].name, 'scmispo01');
                        assert.equal(JSON.parse(row[0][0].value).Port, config.managementPort);
                        assert.equal(row[0][1].name, 'wcmis073');
                        assert.equal(JSON.parse(row[0][1].value).Port, config.managementPort);
                        pool.cql("SELECT * FROM Servers_Test WHERE KEY = ?", ['user:testuser'], function (err, row) {
                            assert.equal(row[0].length, 2);
                            assert.equal(row[0][0].name, 'testgroup');
                            assert.equal(row[0][0].value, 'false');
                            assert.equal(row[0][1].name, 'testgroup_2');
                            assert.equal(row[0][1].value, 'false');
                            pool.cql("SELECT * FROM Servers_Test WHERE KEY = ?", ['group:testgroup'], function (err, row) {
                                assert.equal(row[0].length, 2);
                                assert.equal(row[0][0].name, 'scmispo01');
                                assert.equal(row[0][1].name, 'wcmis073');
                                pool.cql("SELECT * FROM Servers_Test WHERE KEY = ?", ['wcmis073'], function (err, row) {
                                    assert.equal(row[0].length, 2);
                                    assert.equal(row[0][0].name, 'managementPort');
                                    assert.equal(row[0][0].value, config.managementPort);
                                    assert.equal(row[0][1].name, 'testgroup');
                                    var configObj = JSON.parse(row[0][1].value);
                                    assert.equal(configObj.ListenServer, true);
                                    assert.equal(configObj.ListenCpu, true);
                                    assert.equal(configObj.Interval, 5);
                                    assert.equal(configObj.ListenMemory, true);
                                    done();
                                });
                            });
                        });
                    });


                });
            });

            it('Exception', function (done) {

                dao.addServer(null, function (result) {
                    assert.equal(result.StatusCode, 500);
                    dao.addServer({
                        Name: 'wcmis073'
                    }, function (result) {
                        assert.equal(result.StatusCode, 500);
                        dao.addServer({
                            GroupName: 'testgroup'
                        }, function (result) {
                            assert.equal(result.StatusCode, 500);
                            done();
                        });
                    });

                });
            });
        });
        describe('#updateServer()', function () {
            it('Normal', function (done) {
                dao.updateServer({
                    GroupName: 'testgroup',
                    Name: 'wcmis073',
                    Listen: false,
                    Interval: 20,
                    ManagementPort: 1234,
                    IP: '127.0.0.1',
                    Memo: 'Hello World',
                    Cpu: {
                        Listen: false,
                        Juevalue: 30
                    },
                    Memory: {
                        Listen: false,
                        Juevalue: 40
                    },
                    Disk: [{
                        Name: 'D:\\',
                        Listen: true,
                        Juevalue: 100
                    }],
                    Modules: [{
                        Name: 'testjob',
                        Listen: true,
                        Interval: 200,
                        ModuleType: 'Job'
                    }, {
                        Name: 'testweb',
                        Listen: true,
                        Interval: 300,
                        ModuleType: 'Web',
                        URI: ':200/test/roger/123.txt',
                        ValidType: 'content',
                        ValidValue: 'hello world'
                    }]
                }, function (result) {
                    assert.equal(result.StatusCode, 200);

                    pool.cql("SELECT * FROM Servers_Test WHERE KEY = ?", ['wcmis073'], function (err, row) {
                        assert.equal(row[0].length, 2);
                        assert.equal(row[0][0].name, 'managementPort');
                        assert.equal(row[0][0].value, '8701');
                        assert.equal(row[0][1].name, 'testgroup');
                        var configObj = JSON.parse(row[0][1].value);
                        assert.equal(configObj.ListenServer, false);
                        assert.equal(configObj.Interval, 20);
                        assert.equal(configObj.Memo, 'Hello World');
                        assert.equal(configObj.ListenCpu, false);
                        assert.equal(configObj.CpuJuevalue, 30);
                        assert.equal(configObj.ListenMemory, false);
                        assert.equal(configObj.MemoryJuevalue, 40);
                        assert.equal(configObj.IP, '127.0.0.1');
                        assert.equal(configObj.Disk.length, 1);
                        assert.equal(configObj.Disk[0].Name, 'D:\\');
                        assert.equal(configObj.Disk[0].Listen, true);
                        assert.equal(configObj.Disk[0].Juevalue, 100);
                        assert.equal(configObj.Webs.length, 1);
                        assert.equal(configObj.Webs[0].Name, 'testweb');
                        assert.equal(configObj.Webs[0].Listen, true);
                        assert.equal(configObj.Webs[0].Interval, 300);
                        assert.equal(configObj.Webs[0].URI, ':200/test/roger/123.txt');
                        assert.equal(configObj.Webs[0].ValidType, 'content');
                        assert.equal(configObj.Webs[0].ValidValue, 'hello world');
                        assert.equal(configObj.Jobs.length, 1);
                        assert.equal(configObj.Jobs[0].Name, 'testjob');
                        assert.equal(configObj.Jobs[0].Listen, true);
                        assert.equal(configObj.Jobs[0].Interval, 200);

                        pool.cql("SELECT ? FROM Servers_Test WHERE KEY = ?", ['wcmis073', 'servers'], function (err, row) {
                            assert.equal(row[0].length, 1);
                            assert.equal(row[0][0].name, 'wcmis073');
                            var serverObj = JSON.parse(row[0][0].value);
                            assert.equal(serverObj.IP, "127.0.0.1");
                            assert.equal(serverObj.Port, 8701);
                            done();
                        });
                    });

                });
            });

            it('Exception', function (done) {
                dao.updateServer(null, function (result) {
                    assert.equal(result.StatusCode, 500);
                    dao.updateServer({
                        Name: 'wcmis073'
                    }, function (result) {
                        assert.equal(result.StatusCode, 500);
                        done();
                    });
                });
            });
        });
        describe('#getServers()', function () {

            before(function (done) {
                pool.cql("INSERT INTO Servers_Test (key,cahce) VALUES('scmispo01',?)", [JSON.stringify({
                    "Tasks": [], "Name": "scmispo01", "Platform": "Linux",
                    "Memory": { "Process": 27.13, "Description": "2.82 G free of 3.86 G" },
                    "Disk": [{ "Process": 12, "Name": "/", "Description": "31.9 G free of 35.89 G" },
                        { "Process": 18, "Name": "/home", "Description": "7.4 G free of 8.99 G" },
                        { "Process": 14, "Name": "/boot", "Description": "0.08 G free of 0.1 G" },
                        { "Process": 0, "Name": "/dev/shm", "Description": "1.93 G free of 1.93 G" },
                        { "Process": 2, "Name": "/mnt/dfis", "Description": "0.01 G free of 0.01 G" }],
                    "Cpu": {
                        "Process": 0, "Speed": 0, "Description": "x86_64",
                        "Cpus": [{ "Process": 0, "Core": 1 }, { "Process": 0, "Core": 2 }]
                    }, "ManagementPort": 8701, "IP": null
                })], function (err, result) { done() });
            });

            it('Normal', function (done) {
                dao.getServers('testuser', function (result) {
                    assert.equal(result.length, 2);
                    assert.equal(result[0].Name, 'testgroup');
                    assert.equal(result[1].Name, 'testgroup_2');
                    assert.equal(result[0].ReadOnly, 'false');
                    assert.equal(result[1].ReadOnly, 'false');
                    assert.equal(result[0].Servers.length, 2);
                    assert.equal(result[1].Servers.length, 1);
                    assert.equal(result[0].Servers[0].Name, 'scmispo01');
                    assert.equal(result[0].Servers[1].Name, 'wcmis073');
                    assert.equal(result[1].Servers[0].Name, 'scmispo01');

                    assert.equal(result[0].Servers[0].ManagementPort, 8701);
                    assert.equal(result[0].Servers[1].ManagementPort, 8701);
                    assert.equal(result[1].Servers[0].ManagementPort, 8701);

                    assert.equal(result[0].Servers[0].Listen, true);
                    assert.equal(result[0].Servers[1].Listen, false);
                    assert.equal(result[1].Servers[0].Listen, true);

                    assert.equal(result[0].Servers[0].Memo, undefined);
                    assert.equal(result[0].Servers[1].Memo, 'Hello World');
                    assert.equal(result[1].Servers[0].Memo, undefined);

                    assert.equal(result[0].Servers[0].IP, undefined);
                    assert.equal(result[0].Servers[1].IP, '127.0.0.1');
                    assert.equal(result[1].Servers[0].IP, undefined);

                    assert.equal(result[0].Servers[0].Cpu.Listen, true);
                    assert.equal(result[0].Servers[1].Cpu.Listen, false);
                    assert.equal(result[1].Servers[0].Cpu.Listen, true);

                    assert.equal(result[0].Servers[0].Cpu.Juevalue, undefined);
                    assert.equal(result[0].Servers[1].Cpu.Juevalue, 30);
                    assert.equal(result[1].Servers[0].Cpu.Juevalue, undefined);

                    assert.equal(result[0].Servers[0].Memory.Listen, true);
                    assert.equal(result[0].Servers[1].Memory.Listen, false);
                    assert.equal(result[1].Servers[0].Memory.Listen, true);

                    assert.equal(result[0].Servers[0].Memory.Juevalue, undefined);
                    assert.equal(result[0].Servers[1].Memory.Juevalue, 40);
                    assert.equal(result[1].Servers[0].Memory.Juevalue, undefined);

                    done();
                })
            });
            it('Exception', function (done) {
                dao.getServers(null, function (result) {
                    assert.equal(result, undefined);
                    dao.getServers('', function (result) {
                        assert.equal(result, undefined);
                        done();
                    })
                })
            });
        })
        describe('#deleteServer()', function () {
            this.timeout(20000);
            it('Normal-remove all', function (done) {
                dao.deleteServer({
                    Name: 'wcmis073',
                    GroupName: 'testgroup'
                }, function (result) {
                    assert.equal(result.StatusCode, 200);

                    pool.cql("SELECT * FROM Servers_Test WHERE KEY = ?", ['wcmis073'], function (err, row) {
                        if (err) {
                            throw new Error(err);
                        }
                        assert.equal(row[0].length, 1);
                        assert.equal(row[0][0].name, 'managementPort');
                        assert.equal(row[0][0].value, '8701');
                        pool.cql("SELECT * FROM Servers_Test WHERE KEY = ?", ['servers'], function (err, row) {
                            if (err) {
                                throw new Error(err);
                            }
                            assert.equal(row[0][0].name, 'scmispo01');
                            assert.equal(JSON.parse(row[0][0].value).Port, 8701);
                            pool.cql("SELECT * FROM Servers_Test WHERE KEY = ?", ['group:testgroup'], function (err, row) {
                                if (err) {
                                    throw new Error(err);
                                }
                                assert.equal(row[0].length, 1);
                                assert.equal(row[0][0].name, 'scmispo01');
                                done();
                            });
                        });
                    });
                })
            });
            it('Normal-remove at group', function (done) {
                dao.deleteServer({
                    Name: 'scmispo01',
                    GroupName: 'testgroup'
                }, function (result) {
                    assert.equal(result.StatusCode, 200);

                    pool.cql("SELECT * FROM Servers_Test WHERE KEY = ?", ['scmispo01'], function (err, row) {
                        if (err) {
                            throw new Error(err);
                        }
                        assert.equal(row[0].length, 3);

                        pool.cql("SELECT * FROM Servers_Test WHERE KEY = ?", ['servers'], function (err, row) {
                            if (err) {
                                throw new Error(err);
                            }
                            assert.equal(row[0].length, 1);
                            assert.equal(row[0][0].name, 'scmispo01');
                            assert.equal(JSON.parse(row[0][0].value).Port, 8701);
                            pool.cql("SELECT * FROM Servers_Test WHERE KEY = ?", ['group:testgroup_2'], function (err, row) {
                                if (err) {
                                    throw new Error(err);
                                }
                                assert.equal(row[0].length, 1);
                                assert.equal(row[0][0].name, 'scmispo01');
                                done();
                            });
                        });
                    });
                })
            });
            it('Exception', function (done) {
                dao.deleteServer(null, function (result) {
                    assert.equal(result.StatusCode, 500);
                    dao.deleteServer({
                        Name: 'wcmis073'
                    }, function (result) {
                        assert.equal(result.StatusCode, 500);
                        dao.deleteServer({
                            GroupName: 'testgroup'
                        }, function (result) {
                            assert.equal(result.StatusCode, 500);
                            done();
                        })
                    })
                })
            })
        })
    })

    describe('Module', function () {
        describe('#addModule()', function (done) {
            it('Normal', function (done) {
                dao.addModule({ GroupName: 'testgroup_2', ServerName: 'scmispo01', ModuleType: 'Job', Description: 'test by roger', Interval: 16, Listen: true, Name: 'TestJob' }, function (result) {
                    assert.equal(result.StatusCode, 200);
                    dao.addModule({ GroupName: 'testgroup_2', ServerName: 'scmispo01', ModuleType: 'Web', Description: 'test by roger', Interval: 26, Listen: true, Name: 'TestWeb', URI: '200/test/roger', ValidType: 'code', ValidValue: 200 }, function (result) {
                        assert.equal(result.StatusCode, 200);
                        dao.getServers('testuser', function (result) {
                            assert.equal(result[0].Servers[0].Modules.length, 2);
                            assert.equal(result[0].Servers[0].Modules[0].ModuleType, 'Job');
                            assert.equal(result[0].Servers[0].Modules[0].Description, 'test by roger');
                            assert.equal(result[0].Servers[0].Modules[0].Interval, 16);
                            assert.equal(result[0].Servers[0].Modules[0].Listen, true);
                            assert.equal(result[0].Servers[0].Modules[0].Name, 'TestJob');

                            assert.equal(result[0].Servers[0].Modules[1].ModuleType, 'Web');
                            assert.equal(result[0].Servers[0].Modules[1].Description, 'test by roger');
                            assert.equal(result[0].Servers[0].Modules[1].Interval, 26);
                            assert.equal(result[0].Servers[0].Modules[1].Listen, true);
                            assert.equal(result[0].Servers[0].Modules[1].Name, 'TestWeb');
                            assert.equal(result[0].Servers[0].Modules[1].URI, '200/test/roger');
                            assert.equal(result[0].Servers[0].Modules[1].ValidType, 'code');
                            assert.equal(result[0].Servers[0].Modules[1].ValidValue, 200);
                            done();
                        });
                    });
                });
            });

            it('Exception', function (done) {
                dao.addModule({ GroupName: 'testgroup_2' }, function (result) {
                    assert.equal(result.StatusCode, 500);
                    dao.addModule({ GroupName: 'testgroup_2', ServerName: '', ModuleType: '' }, function (result) {
                        assert.equal(result.StatusCode, 500);
                        dao.addModule({}, function (result) {
                            assert.equal(result.StatusCode, 500);
                            done();
                        });
                    });
                });
            });

        });

        describe('#updateModule()', function (done) {
            it('Normal', function (done) {
                dao.updateModule({ GroupName: 'testgroup_2', ServerName: 'scmispo01', ModuleType: 'Job', Description: 'test by roger', Interval: 46, Listen: false, Name: 'TestJob' }, function (result) {
                    assert.equal(result.StatusCode, 200);
                    dao.updateModule({ GroupName: 'testgroup_2', ServerName: 'scmispo01', ModuleType: 'Web', Description: 'test by roger', Interval: 56, Listen: false, Name: 'TestWeb', URI: '200/test/roger', ValidType: 'code', ValidValue: 500 }, function (result) {
                        assert.equal(result.StatusCode, 200);
                        dao.getServers('testuser', function (result) {
                            assert.equal(result[0].Servers[0].Modules.length, 2);
                            assert.equal(result[0].Servers[0].Modules[0].ModuleType, 'Job');
                            assert.equal(result[0].Servers[0].Modules[0].Description, 'test by roger');
                            assert.equal(result[0].Servers[0].Modules[0].Interval, 46);
                            assert.equal(result[0].Servers[0].Modules[0].Listen, false);
                            assert.equal(result[0].Servers[0].Modules[0].Name, 'TestJob');

                            assert.equal(result[0].Servers[0].Modules[1].ModuleType, 'Web');
                            assert.equal(result[0].Servers[0].Modules[1].Description, 'test by roger');
                            assert.equal(result[0].Servers[0].Modules[1].Interval, 56);
                            assert.equal(result[0].Servers[0].Modules[1].Listen, false);
                            assert.equal(result[0].Servers[0].Modules[1].Name, 'TestWeb');
                            assert.equal(result[0].Servers[0].Modules[1].URI, '200/test/roger');
                            assert.equal(result[0].Servers[0].Modules[1].ValidType, 'code');
                            assert.equal(result[0].Servers[0].Modules[1].ValidValue, 500);
                            done();
                        });
                    });
                });
            });

            it('Exception', function (done) {
                dao.updateModule({ GroupName: 'testgroup_2' }, function (result) {
                    assert.equal(result.StatusCode, 500);
                    dao.updateModule({ GroupName: 'testgroup_2', ServerName: '', ModuleType: '' }, function (result) {
                        assert.equal(result.StatusCode, 500);
                        dao.updateModule({}, function (result) {
                            assert.equal(result.StatusCode, 500);
                            done();
                        });
                    });
                });
            });

        });

        describe('#deleteModule()', function (done) {
            it('Normal', function (done) {
                dao.deleteModule({ GroupName: 'testgroup_2', ServerName: 'scmispo01', ModuleType: 'Job', Name: 'TestJob' }, function (result) {
                    assert.equal(result.StatusCode, 200);
                    dao.getServers('testuser', function (result) {
                        assert.equal(result[0].Servers[0].Modules.length, 1);
                        assert.equal(result[0].Servers[0].Modules[0].ModuleType, 'Web');
                        assert.equal(result[0].Servers[0].Modules[0].Description, 'test by roger');
                        assert.equal(result[0].Servers[0].Modules[0].Interval, 56);
                        assert.equal(result[0].Servers[0].Modules[0].Listen, false);
                        assert.equal(result[0].Servers[0].Modules[0].Name, 'TestWeb');
                        assert.equal(result[0].Servers[0].Modules[0].URI, '200/test/roger');
                        assert.equal(result[0].Servers[0].Modules[0].ValidType, 'code');
                        assert.equal(result[0].Servers[0].Modules[0].ValidValue, 500);
                        dao.deleteModule({ GroupName: 'testgroup_2', ServerName: 'scmispo01', ModuleType: 'Web', Name: 'TestWeb' }, function (result) {
                            assert.equal(result.StatusCode, 200);
                            dao.getServers('testuser', function (result) {
                                assert.equal(result[0].Servers[0].Modules.length, 0);
                                done();
                            });
                        });
                    });
                });
            });

            it('Exception', function (done) {
                dao.deleteModule({ GroupName: 'testgroup_2' }, function (result) {
                    assert.equal(result.StatusCode, 500);
                    dao.deleteModule({ GroupName: 'testgroup_2', ServerName: '', ModuleType: '' }, function (result) {
                        assert.equal(result.StatusCode, 500);
                        dao.deleteModule({}, function (result) {
                            assert.equal(result.StatusCode, 500);
                            done();
                        });
                    });
                });
            });

        });

    });

    describe('GroupAuthorization', function () {
        this.timeout(10000);
        before(function (done) {

            pool.cql("TRUNCATE Servers_Test", [], function (err, result) {
                if (err) {
                    throw new Error(err);
                }
                dao.init(function (err) {
                    if (err) {
                        throw new Error(err);
                    }
                    dao.addGroup({
                        Name: 'testgroup',
                        UserID: 'testuser',
                        Servers: [{
                            Name: 'scmispo01'
                        }, {
                            Name: 'scmispo02'
                        }]
                    }, function (result) {
                        assert.equal(result.StatusCode, 200);
                        dao.addGroup({
                            Name: 'testgroup_2',
                            UserID: 'testuser',
                            Servers: [{
                                Name: 'scmispo03'
                            }, {
                                Name: 'scmispo04'
                            }]
                        }, function (result) {
                            assert.equal(result.StatusCode, 200);
                            done();
                        });
                    });
                });
            });
        });

        describe('#getGroupAuthorization()', function () {
            it('Normal', function (done) {
                dao.getGroupAuthorization('testuser', function (result) {
                    assert.equal(result.length, 2);
                    assert.equal(result[0].Name, 'testgroup');
                    assert.equal(result[0].Users.length, 1);
                    assert.equal(result[0].Users[0].UserID, 'testuser');
                    assert.equal(result[0].Users[0].ReadOnly, 'false');
                    assert.equal(result[1].Name, 'testgroup_2');
                    assert.equal(result[1].Users.length, 1);
                    assert.equal(result[1].Users[0].UserID, 'testuser');
                    assert.equal(result[1].Users[0].ReadOnly, 'false');
                    done();
                });
            });

            it('Exception', function (done) {
                dao.getGroupAuthorization(null, function (result) {
                    assert.equal(result.StatusCode, 500);
                    dao.getGroupAuthorization('', function (result) {
                        assert.equal(result.StatusCode, 500);
                        done();
                    });
                });
            });
        });

        describe('#updateGroupAuthorization()', function () {
            it('Normal', function (done) {
                dao.updateGroupAuthorization({ Name: 'testgroup', Users: [{ UserID: 'testuser', ReadOnly: 'true' }] }, function (result) {
                    assert.equal(result.StatusCode, 200);
                    dao.getGroupAuthorization('testuser', function (result) {
                        assert.equal(result.length, 1);
                        assert.equal(result[0].Name, 'testgroup_2');
                        assert.equal(result[0].Users.length, 1);
                        assert.equal(result[0].Users[0].UserID, 'testuser');
                        assert.equal(result[0].Users[0].ReadOnly, 'false');
                        done();
                    });
                });
            });

            it('Exception', function (done) {
                dao.updateGroupAuthorization(null, function (result) {
                    assert.equal(result.StatusCode, 500);
                    dao.updateGroupAuthorization('', function (result) {
                        assert.equal(result.StatusCode, 500);
                        dao.updateGroupAuthorization({ Name: null }, function (result) {
                            assert.equal(result.StatusCode, 500);
                            dao.updateGroupAuthorization({ Name: '' }, function (result) {
                                assert.equal(result.StatusCode, 500);
                                dao.updateGroupAuthorization({ Name: 'test', Users: null }, function (result) {
                                    assert.equal(result.StatusCode, 500);
                                    dao.updateGroupAuthorization({ Name: 'test', Users: { UserID: 'testuser', ReadOnly: 'true' } }, function (result) {
                                        assert.equal(result.StatusCode, 500);
                                        done();
                                    });
                                });
                            });
                        });
                    });
                });
            });
        });

        describe('#deleteGroupAuthorization()', function () {
            it('Normal', function (done) {
                dao.deleteGroupAuthorization({ Name: 'testgroup_2', Users: [{ UserID: 'testuser' }] }, function (result) {
                    assert.equal(result.StatusCode, 200);
                    dao.getGroupAuthorization('testuser', function (result) {
                        assert.equal(result.length, 0);
                        done();
                    });
                });
            });

            it('Exception', function (done) {
                dao.deleteGroupAuthorization(null, function (result) {
                    assert.equal(result.StatusCode, 500);
                    dao.deleteGroupAuthorization('', function (result) {
                        assert.equal(result.StatusCode, 500);
                        dao.deleteGroupAuthorization({ Name: null }, function (result) {
                            assert.equal(result.StatusCode, 500);
                            dao.deleteGroupAuthorization({ Name: '' }, function (result) {
                                assert.equal(result.StatusCode, 500);
                                dao.deleteGroupAuthorization({ Name: 'test', Users: null }, function (result) {
                                    assert.equal(result.StatusCode, 500);
                                    dao.deleteGroupAuthorization({ Name: 'test', Users: { UserID: 'testuser', ReadOnly: 'true' } }, function (result) {
                                        assert.equal(result.StatusCode, 500);
                                        done();
                                    });
                                });
                            });
                        });
                    });
                });
            });
        });
    });

    describe('GroupAuthorizationByUserGroup', function () {


        function initEmailGroup(groups, model, done) {
            pool.cql('TRUNCATE Servers_Test', [], function (err) {
                if (err) {
                    throw new Error(err);
                }
                model.Groups = model.Groups || [];
                model.Users = model.Users || [];
                var commandline = "BEGIN BATCH USING CONSISTENCY QUORUM ";
                var commandparams = [];

                async.each(model.Groups, function (emailgroup, callback) {
                    commandline += " INSERT INTO " + config.cassandra.columnFamily + " (KEY, ?) VALUES (?, ?) ";
                    commandparams.push(emailgroup.GroupName);
                    commandparams.push("group:" + model.Name + ":groups");
                    commandparams.push(emailgroup.ReadOnly);
                    sqlite.getGroupUsers(emailgroup.GroupName, function (err, result) {
                        if (!err && result) {
                            var users = result.users.split(',');
                            for (var j = 0; j < users.length; j++) {
                                var userId = users[j].trim();
                                commandline += " INSERT INTO " + config.cassandra.columnFamily + " (KEY, ?) VALUES (?, ?) ";
                                commandparams.push(model.Name);
                                commandparams.push("user:" + userId);
                                commandparams.push(emailgroup.ReadOnly);
                            }
                        }
                        callback(null);
                    });

                }, function (err) {
                    if (err) {
                        throw new Error(err);
                    }
                    for (var i = 0; i < model.Users.length; i++) {
                        var usermodel = model.Users[i];
                        commandline += " INSERT INTO " + config.cassandra.columnFamily + " (KEY, ?) VALUES (?, ?) INSERT INTO " + config.cassandra.columnFamily + " (KEY, ?) VALUES (?, ?) ";
                        commandparams.push(usermodel.UserID);
                        commandparams.push('group:' + model.Name + ':users');
                        commandparams.push(usermodel.ReadOnly);
                        commandparams.push(model.Name);
                        commandparams.push('user:' + usermodel.UserID);
                        commandparams.push(usermodel.ReadOnly);
                    }

                    for (var i = 0; i < groups.length; i++) {
                        var group = groups[i];
                        commandline += " INSERT INTO " + config.cassandra.columnFamily + " (KEY, ?) VALUES (?, ?) INSERT INTO " + config.cassandra.columnFamily + " (KEY, ?) VALUES (?, ?) ";
                        commandparams.push(group.UserID);
                        commandparams.push('group:' + group.Name + ':users');
                        commandparams.push(false);
                        commandparams.push(group.Name);
                        commandparams.push('user:' + group.UserID);
                        commandparams.push(false);
                    }
                    commandline += " APPLY BATCH;";
                    pool.cql(commandline, commandparams, function (err) {
                        if (err) {
                            throw new Error(err);
                        }
                        setTimeout(done, 10);
                    });

                });

            });

        };

        describe('#updateGroupAuthorizationByUserGroup()', function () {
            this.timeout(20000);
            var model = {
                Name: 'gdev',
                Groups: []
            };
            describe('group:{groupname}:groups check', function () {
                it('Normal', function (done) {

                    model.Groups = [
                        { GroupName: '* gp team mis nesc cncd po', ReadOnly: true },
                        { GroupName: '* gp team mis nesc cncd dfis', ReadOnly: false }];
                    initEmailGroup(groups, model, function () {
                        dao.updateGroupAuthorizationByUserGroup(model, function (result) {
                            assert.equal(result.StatusCode, 200);

                            async.each(model.Groups, function (group, callback) {
                                pool.cql('SELECT ? FROM ' + config.cassandra.columnFamily + ' WHERE KEY = ?'
                                    , [group.GroupName, 'group:' + model.Name + ':groups']
                                    , function (err, rows) {
                                        if (err) {
                                            throw new Error(err);
                                        }
                                        var row = rows[0];
                                        assert.equal(row[0].value, group.ReadOnly.toString());
                                        callback(null);
                                    })

                            }, function (err) {
                                done();
                            });
                        });
                    });
                });
            });

            describe('user:{userid} check', function () {
                it('Normal', function (done) {
                    model.Groups = [{ GroupName: '* gp team mis nesc cncd po', ReadOnly: true }];
                    initEmailGroup(groups, model, function () {

                        dao.updateGroupAuthorizationByUserGroup(model, function (result) {
                            assert.equal(result.StatusCode, 200);
                            var group = model.Groups[0];
                            sqlite.getGroupUsers(group.GroupName, function (err, result) {
                                if (err || !result || !result.users) {
                                    throw new Error(err || 'result is null');
                                }
                                var users = result.users.split(',');
                                async.each(users, function (userId, callback) {
                                    pool.cql("SELECT ? FROM Servers_Test WHERE KEY = ?", [model.Name, 'user:' + userId.trim()], function (err, rows) {
                                        if (err) {
                                            throw new Error(err);
                                        }
                                        if (userId === groups[0].UserID) {
                                            assert.equal(rows[0][0].value, 'false');
                                        } else {
                                            assert.equal(rows[0][0].value, group.ReadOnly.toString());
                                        }
                                        callback(null);
                                    })

                                }, function (err) {
                                    if (err) {
                                        throw new Error(err);
                                    }
                                    done();
                                });
                            });

                        });
                    });

                });
            });

            describe('multiple email group user:{userid} check', function () {
                it('Normal', function (done) {
                    model.Groups = [];
                    model.Groups = [
                        { GroupName: '* gp team mis nesc cncd dfis', ReadOnly: false },
                        { GroupName: '* gp team mis nesc cncd po', ReadOnly: true }];
                    var commandline = 'SELECT ? FROM ' + config.cassandra.columnFamily + ' WHERE KEY = ?';
                    var commandparams = [model.Name, 'user:cc3i'];
                    initEmailGroup(groups, model, function () {
                        dao.updateGroupAuthorizationByUserGroup(model, function (result) {
                            assert.equal(result.StatusCode, 200);
                            pool.cql(commandline, [].concat(commandparams), function (err, rows) {
                                if (err) {
                                    throw new Error(err);
                                }
                                assert.equal(rows[0][0].value, 'false');
                                model.Groups[0].ReadOnly = true;
                                dao.updateGroupAuthorizationByUserGroup(model, function () {
                                    pool.cql(commandline, [].concat(commandparams), function (err, rows) {
                                        if (err) {
                                            throw new Error(err);
                                        }
                                        assert.equal(rows[0][0].value, 'true');
                                        model.Groups[0].ReadOnly = false;
                                        model.Groups[1].ReadOnly = false;
                                        dao.updateGroupAuthorizationByUserGroup(model, function () {
                                            pool.cql(commandline, [].concat(commandparams), function (err, rows) {
                                                if (err) {
                                                    throw new Error(err);
                                                }
                                                assert.equal(rows[0][0].value, 'false');
                                                done();
                                            });
                                        });
                                    });
                                });
                            });
                        });
                    });
                });
            });

            describe('share user with multiple email group user:{userid} check', function () {
                it('Normal', function (done) {
                    model.Groups = [];
                    model.Users = [{ UserID: 'cc3i', ReadOnly: false }];
                    var commandline = 'SELECT ? FROM ' + config.cassandra.columnFamily + ' WHERE KEY = ?';
                    var commandparams = [model.Name, 'user:cc3i'];
                    initEmailGroup(groups, model, function () {
                        model.Groups = [{ GroupName: '* gp team mis nesc cncd po', ReadOnly: true }, { GroupName: '* gp team mis nesc cncd dfis', ReadOnly: false }];

                        dao.updateGroupAuthorizationByUserGroup(model, function () {
                            pool.cql(commandline, [].concat(commandparams), function (err, rows) {
                                if (err) {
                                    throw new Error(err);
                                }
                                assert.equal(rows[0][0].value, 'false');
                                model.Users[0].ReadOnly = true;
                                model.Groups = [];

                                initEmailGroup(groups, model, function () {
                                    model.Groups = [{ GroupName: '* gp team mis nesc cncd po', ReadOnly: true }, { GroupName: '* gp team mis nesc cncd dfis', ReadOnly: false }];
                                    dao.updateGroupAuthorizationByUserGroup(model, function () {
                                        pool.cql(commandline, [].concat(commandparams), function (err, rows) {
                                            if (err) {
                                                throw new Error(err);
                                            }
                                            assert.equal(rows[0][0].value, 'true');
                                            done();
                                        });
                                    });
                                });


                            });
                        });


                    });
                });
            });

            describe('Exception', function () {
                it('Normal', function (done) {
                    dao.updateGroupAuthorizationByUserGroup(null, function (result) {
                        assert.equal(result.StatusCode, 500);
                        dao.updateGroupAuthorizationByUserGroup('', function (result) {
                            assert.equal(result.StatusCode, 500);
                            dao.updateGroupAuthorizationByUserGroup({ Name: null }, function (result) {
                                assert.equal(result.StatusCode, 500);
                                dao.updateGroupAuthorizationByUserGroup({ Name: '' }, function (result) {
                                    assert.equal(result.StatusCode, 500);
                                    dao.updateGroupAuthorizationByUserGroup({ Name: 'test', Groups: null }, function (result) {
                                        assert.equal(result.StatusCode, 500);
                                        dao.updateGroupAuthorizationByUserGroup({ Name: 'test', Groups: { GroupName: 'testuser', ReadOnly: 'true' } }, function (result) {
                                            assert.equal(result.StatusCode, 500);
                                            done();
                                        });
                                    });
                                });
                            });
                        });
                    });
                });
            });
        });

        describe('#getGroupAuthorizationByUserGroup()', function () {
            this.timeout(20000);
            var model = {
                Name: 'gdev',
                Groups: [
                    { GroupName: '* gp team mis nesc cncd po', ReadOnly: true },
                    { GroupName: '* gp team mis nesc cncd eims', ReadOnly: true }
                ]
            };
            before(function (done) {
                initEmailGroup(groups, model, done);
            });
            it('Normal', function (done) {
                dao.getGroupAuthorizationByUserGroup('by46', function (sharegroups) {

                    assert.equal(sharegroups.length, 1);
                    var sharegroup = sharegroups[0];
                    assert.equal(sharegroup.Groups.length, 2);
                    assert.equal(sharegroup.Name, model.Name);

                    var found = false;
                    for (var j = 0; j < model.Groups.length; j++) {
                        found = false;
                        for (var k = 0; k < sharegroup.Groups.length; k++) {
                            if (model.Groups[j].GroupName === sharegroup.Groups[k].GroupName) {
                                found = true;
                                break;
                            }
                        }
                        assert.equal(found, true);
                    }
                    done();
                });

            });

            it('Exception', function (done) {
                dao.getGroupAuthorizationByUserGroup(null, function (result) {
                    assert.equal(result.StatusCode, 500);
                    dao.getGroupAuthorizationByUserGroup('', function (result) {
                        assert.equal(result.StatusCode, 500);
                        done();
                    });
                });
            });
        });

        describe('#deleteGroupAuthorizationByUserGroup()', function () {
            var model = {
                Name: 'gdev',
                Groups: [{ GroupName: '* gp team mis nesc cncd po', ReadOnly: true }, { GroupName: '* gp team mis nesc cncd dfis', ReadOnly: true }]
            };
            describe('group:{groupname}:groups check', function () {
                it('Normal', function (done) {
                    var commandline = 'SELECT ? FROM ' + config.cassandra.columnFamily + ' WHERE KEY = ?';
                    var params = ['group:' + model.Name + ':groups'];
                    initEmailGroup(groups, model, function () {
                        model.Groups = [{ GroupName: '* gp team mis nesc cncd dfis', ReadOnly: true }];
                        dao.deleteGroupAuthorizationByUserGroup(model, function (result) {
                            assert.equal(result.StatusCode, 200);
                            var group = model.Groups[0];
                            pool.cql(commandline, [group.GroupName].concat(params), function (err, rows) {
                                if (err) {
                                    throw new Error(err);
                                }
                                assert.equal(rows[0][0].value, null);
                                done();
                            });
                        });
                    });
                });
            });

            describe('delete single share email group: user:{userid} check', function () {
                it('Normal', function (done) {
                    model.Groups = [{ GroupName: '* gp team mis nesc cncd po', ReadOnly: true }]
                    initEmailGroup(groups, model, function () {
                        dao.deleteGroupAuthorizationByUserGroup(model, function (result) {
                            assert.equal(result.StatusCode, 200);
                            var group = model.Groups[0];
                            sqlite.getGroupUsers(group.GroupName, function (err, result) {

                                if (err) {
                                    throw new Error(err);
                                }
                                if (result && result.users) {
                                    var users = result.users.split(',');
                                    async.each(users, function (userId, callback) {
                                        pool.cql('SELECT ? FROM ' + config.cassandra.columnFamily + ' WHERE KEY = ?'
                                            , [model.Name, 'user:' + userId]
                                            , function (err, rows) {
                                                if (userId == groups[0].UserID) {
                                                    assert.equal(rows[0][0].value, 'false');
                                                } else {
                                                    assert.equal(rows[0][0].value, null);
                                                }
                                                callback(null);
                                            });
                                    }, function () {
                                        done();
                                    });
                                } else {
                                    done();
                                }
                            });
                        });
                    });
                });
            });

            describe('delete multiple share email group: user:cc3i check', function () {
                this.timeout(10000);
                it('Normal', function (done) {
                    model.Groups = [{ GroupName: '* gp team mis nesc cncd po', ReadOnly: true }, { GroupName: '* gp team mis nesc cncd dfis', ReadOnly: true }];
                    var commandline = 'SELECT ? FROM ' + config.cassandra.columnFamily + ' WHERE KEY = ?';
                    var params = [model.Name, 'user:cc3i'];
                    initEmailGroup(groups, model, function () {
                        model.Groups = [{ GroupName: '* gp team mis nesc cncd dfis' }];
                        dao.deleteGroupAuthorizationByUserGroup(model, function (result) {
                            assert.equal(result.StatusCode, 200);
                            pool.cql(commandline, [].concat(params), function (err, rows) {
                                if (err) {
                                    throw new Error(err);
                                }
                                assert.equal(rows[0][0].value, 'true');
                                model.Groups = [{ GroupName: '* gp team mis nesc cncd po', ReadOnly: true }, { GroupName: '* gp team mis nesc cncd dfis', ReadOnly: false }];
                                initEmailGroup(groups, model, function () {
                                    model.Groups = [{ GroupName: '* gp team mis nesc cncd po' }];
                                    dao.deleteGroupAuthorizationByUserGroup(model, function (result) {
                                        assert.equal(result.StatusCode, 200);
                                        pool.cql(commandline, [].concat(params), function (err, rows) {
                                            if (err) {
                                                throw new Error(err);
                                            }
                                            assert.equal(rows[0][0].value, 'false');
                                            model.Groups = [{ GroupName: '* gp team mis nesc cncd po', ReadOnly: true }, { GroupName: '* gp team mis nesc cncd dfis', ReadOnly: false }];
                                            initEmailGroup(groups, model, function () {
                                                model.Groups = [{ GroupName: '* gp team mis nesc cncd dfis' }];
                                                dao.deleteGroupAuthorizationByUserGroup(model, function (result) {
                                                    assert.equal(result.StatusCode, 200);
                                                    pool.cql(commandline, [].concat(params), function (err, rows) {
                                                        if (err) {
                                                            throw new Error(err);
                                                        }
                                                        assert.equal(rows[0][0].value, 'true');

                                                        done();
                                                    });
                                                });
                                            });
                                        });
                                    });
                                });
                            });
                        });
                    });
                });
            });

            describe('delete multiple share email group with different authorization', function () {
                this.timeout(10000);
                it('Normal', function (done) {
                    model.Groups = [{ GroupName: '* gp team mis nesc cncd po', ReadOnly: false }, { GroupName: '* gp team mis nesc cncd dfis', ReadOnly: true }];
                    model.Users = [{ UserID: 'cc3i', ReadOnly: true }];
                    var commandline = 'SELECT ? FROM ' + config.cassandra.columnFamily + ' WHERE KEY = ?';
                    var params = [model.Name, 'user:cc3i'];
                    initEmailGroup(groups, model, function () {
                        model.Groups = [{ GroupName: '* gp team mis nesc cncd po' }];
                        dao.deleteGroupAuthorizationByUserGroup(model, function (result) {
                            assert.equal(result.StatusCode, 200);
                            pool.cql(commandline, [].concat(params), function (err, rows) {
                                if (err) {
                                    throw new Error(err);
                                }
                                assert.equal(rows[0][0].value, 'true');
                                model.Groups = [{ GroupName: '* gp team mis nesc cncd po', ReadOnly: false }, { GroupName: '* gp team mis nesc cncd dfis', ReadOnly: true }];
                                model.Users = [{ UserID: 'cc3i', ReadOnly: true }];
                                initEmailGroup(groups, model, function () {
                                    model.Groups = [{ GroupName: '* gp team mis nesc cncd dfis' }];
                                    dao.deleteGroupAuthorizationByUserGroup(model, function (result) {
                                        assert.equal(result.StatusCode, 200);
                                        pool.cql(commandline, [].concat(params), function (err, rows) {
                                            if (err) {
                                                throw new Error(err);
                                            }
                                            assert.equal(rows[0][0].value, 'true');
                                            done();
                                        });
                                    });
                                });
                            });
                        });
                    });
                });
            });
        });

        describe('#deleteGroupAuthorizationExtended', function () {

            var deletedUser = { UserID: 'cc3i', ReadOnly: true };
            var model = {
                Name: 'gdev',
                Groups: [{ GroupName: '* gp team mis nesc cncd po', ReadOnly: true },
                        { GroupName: '* gp team mis nesc cncd dfis', ReadOnly: false }],
                Users: [deletedUser]
            };
            function calcAuthorization(emailGroups) {
                emailGroups = emailGroups || [];
                for (var i = 0; i < model.Groups.length; i++) {
                    if (!model.Groups[i].ReadOnly) {
                        return true;
                    }
                }
                return false;
            }
            describe('delete group authorization', function () {
                this.timeout(10000);
                it('Normal', function (done) {
                    model.Groups = model.Groups || [];
                    var cmdline = 'SELECT ? FROM ' + config.cassandra.columnFamily + ' WHERE KEY = ? ';
                    var cmdparams = [model.Name, 'user:cc3i'];

                    initEmailGroup(groups, model, function () {
                        dao.deleteGroupAuthorization({ Name: model.Name, Users: [deletedUser] }, function (result) {
                            assert.equal(result.StatusCode, 200);

                            pool.cql(cmdline, [].concat(cmdparams), function (err, rows) {
                                if (err) {
                                    throw new Error(err);
                                }
                                assert.equal(rows[0][0].value, (!calcAuthorization(model.Groups)).toString());
                                model.Groups = [{ GroupName: '* gp team mis nesc cncd po', ReadOnly: true }, { GroupName: '* gp team mis nesc cncd dfis', ReadOnly: true }];
                                model.User = [deletedUser];
                                initEmailGroup(groups, model, function () {
                                    dao.deleteGroupAuthorization({ Name: model.Name, Users: [deletedUser] }, function (result) {
                                        assert.equal(result.StatusCode, 200);
                                        pool.cql(cmdline, [].concat(cmdparams), function (err, rows) {
                                            if (err) {
                                                throw new Error(err);
                                            }
                                            assert.equal(rows[0][0].value, (!calcAuthorization(model.Groups)).toString());
                                            model.Groups = [{ GroupName: '* gp team mis nesc cncd po', ReadOnly: false }, { GroupName: '* gp team mis nesc cncd dfis', ReadOnly: false }];
                                            model.User = [deletedUser];
                                            initEmailGroup(groups, model, function () {
                                                dao.deleteGroupAuthorization({ Name: model.Name, Users: [deletedUser] }, function (result) {
                                                    assert.equal(result.StatusCode, 200);
                                                    pool.cql(cmdline, [].concat(cmdparams), function (err, rows) {
                                                        if (err) {
                                                            throw new Error(err);
                                                        }
                                                        assert.equal(rows[0][0].value, (!calcAuthorization(model.Groups)).toString());

                                                        done();
                                                    });
                                                });
                                            });
                                        });
                                    });
                                });
                            });
                        });
                    });

                });
            });
        });
    });

    describe('Sqlite', function () {
        this.timeout(3600000);

        it('process', function (done) {
            sqliteInstallTest.process(function (success) {
                assert.equal(success, true);
                done();
            });
        });

        //it('install...', function (done) {
        //    sqliteInstallTest.installdb(function (success) {
        //        assert.equal(success, true);
        //        done();
        //    });
        //});

    });
});